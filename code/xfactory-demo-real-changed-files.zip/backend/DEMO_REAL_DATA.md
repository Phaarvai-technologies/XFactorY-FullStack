# Demo vs real manufacturer data

The classification of a company is `organizations.record_type`. It already existed (migration 008)
and is reused. No new column was added.

| Value | Meaning | Visionaries (search, profile, booking) | Onboarding company lookup (other users) | Admin portal |
|---|---|---|---|---|
| `REAL` | real manufacturer data | visible once approved **and** 100% complete | listed | listed, counted in totals and analytics |
| `DEMO` | demonstration data | **never** | not listed (the owner still sees their own) | listed under the Demo tab, Demo badge |
| `TEST` | internal test data (existing) | never | not listed (owner still sees their own) | listed under the Demo tab, Test badge |

The classification is independent of approval (`manufacturer_onboarding.status`), `verification_status`,
`onboarding_source`, `entry_source`, profile completeness and ownership (memberships). Changing it changes
none of these. Users have no classification: a person can own a demo company and a real one.

## Who sets it

| Path | Value |
|---|---|
| Manufacturer self-registration (`/manufacturer/account`) | `REAL` (column default) |
| Admin portal → Add company | Real or Demo: the form requires an explicit choice (the API defaults to `REAL`) |
| CSV import `python -m app.import_manufacturers file.csv --record-type REAL\|DEMO` | the required `--record-type` |
| Research seed files (`seed_part1.sql`, `seed_part2.sql`, `seed_tamil_nadu.sql`) | always `REAL` |
| Change afterwards | admin portal → company → Onboarding & review → **Real or demo data**. Administrators and operators only, a reason is required, and a confirmation dialog explains the effect. Every change is recorded in the company's change history (who, old → new, reason). Support and verification roles can view but not change it (403). |

## Where demo data is excluded (backend)

- `app/core/eligibility.py`: `visionary_visible` and `booking` both require the new fact `real`
  (`record_type = 'REAL'`), on top of approval and completeness. This covers Visionary search,
  recommendations, profile pages, drafts and new requests. Machinery, certifications and availability are
  only read for companies that pass this rule.
- `app/visionary/repository.py` `DISCOVERABLE`: `record_type = 'REAL'` (was `<> 'TEST'`).
- `app/repositories/manufacturer.py`:
  - `LISTED_COMPANY_SQL` (onboarding company search, details, selection, new-company name clash) lists REAL
    companies, plus the viewer's own company.
  - `DEDUP_COMPANY_SQL` (duplicate checks for imports and Admin Entry) keeps DEMO records, so a match with
    demo data is reported, never duplicated.
- The manufacturer's own status (`/manufacturer/bootstrap` → `approval.eligibility`) shows a demo company
  as not visible and not bookable.
- Admin overview cards and analytics already counted REAL only. The manufacturer list returns
  `recordTypeCounts` for the All / Real / Demo tabs, using the same filters as the list.
- `app/services/company_search.py` and `app/claims/service.py` (claim feature, not routed at present): REAL
  only.

## Demo / real conflicts during imports

An import never converts, merges or overwrites an existing record. When a row matches an existing company
of the other classification (same registration id; same name + website; same name + country + city):

- **CSV import** reports `CONFLICT line N: <name> matches DEMO record <name> (<id>)` and skips the row.
- **Research seed files** list the row as `CONFLICT with existing DEMO record (rule …)` in section 8 of
  their output, and skip it.
- **Admin Entry** answers `409 classification_conflict` with the existing id. The form offers "Open the
  existing company".

Resolve each conflict in the admin portal, then re-run the import (re-runs never duplicate):

1. **It is the same real company.** Open the demo record and change it to Real, with a reason. A re-run
   then reports the row as a duplicate of that (now real) record and skips it. The research data is not
   merged in: copy anything useful from the research row (the seed output shows its id; the source
   workbook has the details).
2. **The demo record is unrelated sample data.** Archive it (archived records are not duplicate
   candidates), then re-run the import. The real company is inserted as a new record.

## One-time classification of the existing records

These live in `database/backfills/023_demo_classification/` and are not run by `app.migrate`.

| File | Changes data? | Purpose |
|---|---|---|
| `1_preview.sql` | no | The scope count to approve, and every in-scope record with its relationships (owners and their sign-up channel, shared owners / Visionaries / admins, approval, bookings, engagements, published machines, open requests from others, visible to Visionaries today). |
| `2_apply.sql` | yes | `REAL` → `DEMO` for the scope below. Requires `expected_count` and an optional KEEP-REAL id list. Logs every record (with a snapshot) in `record_type_classification_log` and in `admin_change_history`. Refuses to run twice. One transaction. |
| `3_verify.sql` | no | All `problems_*` columns must be 0. |
| `4_rollback.sql` | yes | Restores `REAL` on exactly the logged records, except records an admin has reclassified since; it lists those and keeps them. |

**Scope.** Records are updated when ALL of these hold; nothing else is updated:

1. `organization_type = 'manufacturer'`
2. `record_type = 'REAL'`
3. `created_at` before the moment `2_apply.sql` runs
4. `source_ref` not `india_mfr_research:%`
5. not in the KEEP-REAL list

What is never touched:
- users;
- buyer / Visionary organizations;
- existing DEMO and TEST rows;
- ids, memberships, owners, approval, verification, onboarding source, archive state, `updated_at`.

What protects later real imports:
- the run-once guard;
- rule 3 (created before the run);
- rule 4 (research seed rows excluded);
- the deployment order below.

## Production deployment order

Take a database backup first. Do steps 2–6 in one maintenance window.

1. **Review.** Run the preview against a copy of production, or read-only:
   `psql "$PROD_URL" -f database/backfills/023_demo_classification/1_preview.sql > preview.txt`.
   Decide the KEEP-REAL ids, if any.
2. **Migrate.** Run `PYTHONPATH=. python -m app.migrate`. It applies 023: it adds `source_ref` where it
   is missing, plus the classification log. It is idempotent, and the running app is unaffected.
3. **Classify the existing records.** Re-run `1_preview.sql`. In `2_apply.sql`, set `expected_count`
   (`in_scope_total` minus the kept ids) and the KEEP-REAL ids, then run
   `psql "$PROD_URL" -v ON_ERROR_STOP=1 -f 2_apply.sql`.
4. **Verify.** Run `3_verify.sql`. Every `problems_*` value must be 0.
5. **Deploy the backend, then the frontend.** From this point the Visionary side hides demo data,
   self-registration creates Real records, and the admin portal has the tabs and badges.
6. **Import the real manufacturer data.** Run `run_seed.py seed_part1.sql`, then `seed_part2.sql`
   (dry run first with `SEED_DRY_RUN=1`). `seed_tamil_nadu.sql` is optional, because every Tamil Nadu
   company is already in the India files.
7. **Resolve conflicts and verify.** Resolve the listed demo conflicts in the admin portal (see above).
   Run `3_verify.sql` again: section 5 must show 0 research rows that are not REAL.

The order matters: step 3 must run before step 6. If the backend is deployed before step 3, nothing
breaks, but existing demo companies stay visible to Visionaries until step 3 runs.

**Rollback.**
- Data: `4_rollback.sql` undoes step 3. Imported research rows can be removed with `unseed.sql`, which
  removes only unclaimed imported rows.
- Code: redeploy the previous version. It ignores DEMO for Visionaries (the old rule hid only TEST) and
  never reads the new log table.
