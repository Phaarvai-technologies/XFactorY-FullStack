"use client";

import { useAuth } from "@clerk/nextjs";
import { usePathname, useRouter } from "next/navigation";
import type {
  CompanySearchResponse,
  CompanySearchResult,
  CompanyDetails,
} from "@/lib/api";
import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type Dispatch,
  type SetStateAction,
} from "react";
import { AccountScreen, type AccountSubmission } from "@/components/manufacturer/AccountScreen";
import { DashboardScreen } from "@/components/manufacturer/DashboardScreen";
import { LandingScreen } from "@/components/manufacturer/LandingScreen";
import { MachineryWizard, type MachineryDraft } from "@/components/manufacturer/MachineryWizard";
import {
  createBlankProfileData,
  ProfileWizard,
  type ProfileWizardData,
} from "@/components/manufacturer/ProfileWizard";
import { RecurringModal } from "@/components/manufacturer/RecurringModal";
import { CheckIcon } from "@/components/manufacturer/icons";
import { api, ApiError } from "@/lib/api";
import { diffFields, diffProfile } from "@/lib/manufacturer/profilePatch";
import {
  isManufacturerAccountPath,
  isManufacturerDashboardPath,
  MANUFACTURER_ACCOUNT_PATH,
  MANUFACTURER_DASHBOARD_PATH,
  MANUFACTURER_OVERVIEW_PATH,
  manufacturerCreateAccountHref,
  markManufacturerProfileComplete,
} from "@/lib/auth/manufacturerAccess";
import {
  createInitialManufacturerState,
  type BookingRequest,
  type MachineryListing,
  type ManufacturerState,
  type RecurringAvailability,
} from "@/lib/manufacturer/types";

type Screen = "landing" | "account" | "dashboard";

/**
 * Shape returned by every Manufacturer API call (GET /manufacturer/bootstrap and
 * all mutations). Identical to the UI state except that database ids are UUIDs.
 */
type ServerSnapshot = {
  accountExists: boolean;
  /** The signed-in user's own saved record (from registration): prefills the details form. */
  user?: { firstName: string; lastName: string; email: string; personalEmail: string };
  state: Omit<ManufacturerState, "machinery" | "bookings"> & {
    machinery: (Omit<MachineryListing, "id"> & { id: string })[];
    bookings: (Omit<BookingRequest, "id"> & { id: string })[];
  };
  profileData: ProfileWizardData;
  /** Company Profile wizard progress, computed by the backend from saved data. */
  profileProgress: ProfileProgress;
  /** Unfinished machinery wizard to continue, or null. */
  machineryDraft: ServerMachineryDraft | null;
  /** Admin approval of the submitted company details (tracked apart from profile completion). */
  approval?: {
    status: "not_submitted" | "pending" | "changes_requested" | "approved" | "rejected";
    kind: "new_company" | "claim" | "update" | null;
    selectedCompanyId?: string | null;
    feedback: string | null;
    /** The user's own update requests for companies managed by someone else (status + feedback). */
    updateRequests?: CompanyUpdateRequest[];
    /** Approval first: what the user may use until X!Y approves their manufacturer application. */
    access?: ApplicationAccess;
  };
  /** What the account form submission became (set on POST /manufacturer/account). */
  submitted?: { kind: string; companyId: string; companyName: string; requestId: string | null } | null;
};

/** The user's manufacturer application and what it unlocks (backend app/manufacturer_access.py). */
export type ApplicationAccess = {
  unlocked: boolean;
  status: "not_submitted" | "pending" | "changes_requested" | "approved" | "rejected";
  role: string | null;
  /** Approved members may not edit the shared company profile (owner / admin only). */
  canEditProfile: boolean;
  /** Shown to the user while locked, e.g. "Your manufacturer application is awaiting admin approval." */
  message: string | null;
  application: {
    id: string;
    kind: string;
    status: string;
    companyId: string;
    companyName: string | null;
    /** X!Y's applicant-facing explanation (never internal notes). */
    feedback: string | null;
    reviewedAt: string | null;
    submittedAt: string | null;
    correctionFields: string[];
  } | null;
  /** Rejected: when a new application may be sent. */
  reapplyAt: string | null;
  canReapply: boolean;
};

export type CompanyUpdateRequest = {
  id: string;
  status: "pending" | "changes_requested" | "approved" | "rejected";
  companyId: string;
  companyName: string;
  proposed: Record<string, string | number | null>;
  feedback: string | null;
  submittedAt: string | null;
  updatedAt: string | null;
  reviewedAt: string | null;
};

type ProfileProgress = {
  status: "draft" | "completed";
  currentStep: number;
  completedSteps: number[];
  resumeStep: number;
  percentage: number;
  checklist: {
    companyDetailsDone: boolean;
    locationDone: boolean;
    certsDone: boolean;
    infraDone: boolean;
    faqDone: boolean;
  };
};

type ServerMachineryDraft = {
  id: string;
  data: MachineryDraft;
  currentStep: number;
  completedSteps: number[];
  resumeStep: number;
};

type StepProgress = { completed: boolean; nextStep: number };

const SAVE_DELAY_MS = 700;

function errorMessage(error: unknown): string {
  if (error instanceof ApiError || error instanceof Error) return error.message;
  return "Something went wrong. Please try again.";
}

function screenFromPathname(pathname: string): Screen {
  if (isManufacturerDashboardPath(pathname)) return "dashboard";
  if (isManufacturerAccountPath(pathname)) return "account";
  return "landing";
}

function applyAccountSubmission(
  submission: AccountSubmission,
  setState: Dispatch<SetStateAction<ManufacturerState>>,
  setProfileData: Dispatch<SetStateAction<ProfileWizardData>>,
) {
  setState((current) => ({
    ...current,
    account: {
      firstName: submission.firstName,
      lastName: submission.lastName,
      companyName: submission.companyName,
      companyType: submission.companyType,
      country: submission.country,
      dob: submission.dob ?? "",
      phone: submission.phone,
      capacity: submission.capacity,
      // the registering user's personal email; the company's contact details come from the server
      personalEmail: submission.email,
    },
  }));
  setProfileData((current) => ({
    ...current,
    company: { ...current.company, name: submission.companyName },
  }));
}

export function ManufacturerApp() {
  const router = useRouter();
  const pathname = usePathname();
  const { isLoaded, isSignedIn, userId, getToken } = useAuth();
  const screen = screenFromPathname(pathname);

  const [state, setState] = useState<ManufacturerState>(createInitialManufacturerState);
  const [profileData, setProfileData] = useState<ProfileWizardData>(() =>
    createBlankProfileData(),
  );
  const [profileWizardOpen, setProfileWizardOpen] = useState(false);
  const [profileWizardStep, setProfileWizardStep] = useState(1);
  const [machineryWizardOpen, setMachineryWizardOpen] = useState(false);
  const [recurringOpen, setRecurringOpen] = useState(false);
  const [toast, setToast] = useState<{ message: string; visible: boolean }>({
    message: "",
    visible: false,
  });
  const toastTimer = useRef<number | null>(null);

  // ---- Backend connection state -------------------------------------------
  /**
   * What the database says about the signed-in user (null = not checked yet).
   * The saved Manufacturer account decides form vs dashboard, so a returning
   * user is never asked for their details again (any device, after sign-out).
   */
  const [server, setServer] = useState<{
    userId: string;
    accountExists: boolean;
    failed: boolean;
    /** Page where loading failed: moving to another manufacturer page tries again. */
    path?: string;
    /** Admin approval of the submitted details; corrections reopen the details form. */
    approval?: ServerSnapshot["approval"] | null;
  } | null>(null);
  const checked =
    server !== null && server.userId === userId && (!server.failed || server.path === pathname);
  /** The admin asked for corrections to the submitted company details: the form may be reopened. */
  /** X!Y asked for corrections to one of the user's update requests for another company. */
  const requestToCorrect = server?.approval?.updateRequests?.find((r) => r.status === "changes_requested") ?? null;
  /** Approval first: remaining sections stay locked until X!Y approves the application. */
  const access = server?.approval?.access ?? null;
  const locked = access !== null && !access.unlocked;
  /** Rejected: a fresh application may be sent once the waiting period has passed. */
  const canReapply = access?.status === "rejected" && access.canReapply;
  const canResubmit = server?.approval?.status === "changes_requested" || requestToCorrect !== null || canReapply;
  /** UI components use numeric ids; the database uses UUIDs. */
  const ids = useRef({ toServer: new Map<number, string>(), toLocal: new Map<string, number>(), next: 1 });
  const profileSaveTimer = useRef<number | null>(null);
  const pendingProfile = useRef<ProfileWizardData | null>(null);
  /** Profile as last loaded from / saved to the database: the PATCH diff baseline. */
  const savedProfile = useRef<ProfileWizardData | null>(null);
  /** Profile saves run one after another, in order. */
  const profileSaveQueue = useRef<Promise<void>>(Promise.resolve());
  /** The user's own registration details (names, emails) for prefilling the details form. */
  const [registered, setRegistered] = useState<ServerSnapshot["user"] | null>(null);
  /** Progress numbers from the backend (dashboard checklist, percentage, resume step). */
  const [profileProgress, setProfileProgress] = useState<ProfileProgress | null>(null);
  /** Machinery wizard: saved-but-unfinished draft, and the open wizard's session. */
  const [machineryDraft, setMachineryDraft] = useState<ServerMachineryDraft | null>(null);
  const machinerySession = useRef<{ id: string | null; clientKey: string; saved: MachineryDraft | null }>({
    id: null,
    clientKey: "",
    saved: null,
  });
  const [machineryStart, setMachineryStart] = useState<{ draft: MachineryDraft | null; step: number }>({
    draft: null,
    step: 1,
  });
  /** One availability save at a time (recurring / capacity buttons). */
  const availabilitySaving = useRef(false);
  const availabilityTimer = useRef<number | null>(null);
  const availabilityDirty = useRef(false);

  const showToast = useCallback((message: string) => {
    setToast({ message, visible: true });
    if (toastTimer.current !== null) {
      window.clearTimeout(toastTimer.current);
    }
    toastTimer.current = window.setTimeout(() => {
      setToast((current) => ({ ...current, visible: false }));
    }, 3000);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimer.current !== null) {
        window.clearTimeout(toastTimer.current);
      }
    };
  }, []);

  const request = useCallback(
    async <T,>(path: string, init: RequestInit = {}): Promise<T> => {
      const token = await getToken();
      if (!token) throw new ApiError(401, "Your session has expired. Please sign in again.");
      return api<T>(path, token, init);
    },
    [getToken],
  );

  const handleSearchCompanies = useCallback(
  async (query: string): Promise<CompanySearchResult[]> => {
    const response = await request<CompanySearchResponse>(
      `/manufacturer/companies/search?q=${encodeURIComponent(query)}`,
    );

    return response.items;
  },
  [request],
);

  const handleLoadCompany = useCallback(
    (companyId: string) => request<CompanyDetails>(`/manufacturer/companies/${encodeURIComponent(companyId)}`),
    [request],
  );

  const localId = useCallback((serverId: string): number => {
    const map = ids.current;
    let id = map.toLocal.get(serverId);
    if (id === undefined) {
      id = map.next++;
      map.toLocal.set(serverId, id);
      map.toServer.set(id, serverId);
    }
    return id;
  }, []);

  const toLocalMachinery = useCallback(
    (items: ServerSnapshot["state"]["machinery"]): MachineryListing[] =>
      items.map((m) => ({ ...m, id: localId(m.id) })),
    [localId],
  );

  const toLocalBookings = useCallback(
    (items: ServerSnapshot["state"]["bookings"]): BookingRequest[] =>
      items.map((b) => ({ ...b, id: localId(b.id) })),
    [localId],
  );

  /** Replace the whole UI state with the server's (initial load / after account creation). */
  const applySnapshot = useCallback(
    (snapshot: ServerSnapshot) => {
      setState({
        ...snapshot.state,
        machinery: toLocalMachinery(snapshot.state.machinery),
        bookings: toLocalBookings(snapshot.state.bookings),
      });
      setProfileData(snapshot.profileData);
      savedProfile.current = snapshot.profileData;
      setProfileProgress(snapshot.profileProgress);
      setMachineryDraft(snapshot.machineryDraft);
      if (snapshot.user) setRegistered(snapshot.user);
    },
    [toLocalBookings, toLocalMachinery],
  );

  /** Show the record the backend saved and read back (requirement: latest DB values). */
  const applySavedProfile = useCallback((snapshot: ServerSnapshot) => {
    setProfileData(snapshot.profileData);
    setState((current) => ({
      ...current,
      epic2: snapshot.state.epic2,
      serviceableAreas: snapshot.state.serviceableAreas,
    }));
    setProfileProgress(snapshot.profileProgress);
  }, []);

  /** Re-read everything after a failed mutation so the UI never shows unsaved data. */
  const resync = useCallback(async () => {
    try {
      const snapshot = await request<ServerSnapshot>("/manufacturer/bootstrap");
      setState((current) => ({
        ...current,
        machinery: toLocalMachinery(snapshot.state.machinery),
        bookings: toLocalBookings(snapshot.state.bookings),
      }));
    } catch {
      // Keep the current screen; the error toast has already been shown.
    }
  }, [request, toLocalBookings, toLocalMachinery]);

  // Auth + route guards (does not replace Clerk; only keeps screens in sync).
  useEffect(() => {
    if (!isLoaded) return;

    if (!isSignedIn) {
      // Dashboard only — account redirects are handled by the server page so we
      // don't race a freshly activated Clerk session after Explore → sign-in/up.
      if (isManufacturerDashboardPath(pathname)) {
        router.replace(MANUFACTURER_OVERVIEW_PATH);
      }
      return;
    }

    if (!checked || server.failed) return;
    // Details already saved -> never show the form again; not saved yet -> fill them first.
    if ((screen === "landing" || (isManufacturerAccountPath(pathname) && !canResubmit)) && server.accountExists) {
      // Existing Manufacturer account: straight to the portal (data is already loaded).
      router.replace(MANUFACTURER_DASHBOARD_PATH);
    } else if (isManufacturerDashboardPath(pathname) && !server.accountExists) {
      router.replace(MANUFACTURER_ACCOUNT_PATH);
    }
  }, [canResubmit, checked, isLoaded, isSignedIn, pathname, router, screen, server]);

  // Load the manufacturer's saved data from the backend.
  useEffect(() => {
    if (!isLoaded || !isSignedIn || !userId) return;
    // Also on the overview page: a signed-in user's saved account decides whether the
    // "Join Our Ecosystem" page is shown at all (see the route guard below).
    if (checked) return;
    let cancelled = false;

    // Right after sign-in the session token can take a moment to be ready, so a missing
    // token / unreachable backend / server error is retried briefly before giving up.
    async function loadWithRetry(): Promise<ServerSnapshot> {
      const delays = [0, 700, 1500];
      for (let attempt = 0; ; attempt++) {
        if (delays[attempt]) await new Promise((resolve) => window.setTimeout(resolve, delays[attempt]));
        try {
          return await request<ServerSnapshot>("/manufacturer/bootstrap");
        } catch (error: unknown) {
          const status = error instanceof ApiError ? error.status : 0;
          const retryable = status === 0 || status === 401 || status >= 500;
          if (cancelled || !retryable || attempt === delays.length - 1) throw error;
        }
      }
    }

    loadWithRetry()
      .then((snapshot) => {
        if (cancelled) return;
        applySnapshot(snapshot);
        if (snapshot.accountExists) markManufacturerProfileComplete();
        setServer({ userId, accountExists: snapshot.accountExists, failed: false,
                    approval: snapshot.approval ?? null });
      })
      .catch((error: unknown) => {
        if (cancelled) return;
        // Backend unreachable: keep the current screen usable and say why.
        setState((current) => ({ ...current, bookings: [] }));
        setServer({ userId, accountExists: false, failed: true, path: pathname });
        showToast(`Couldn’t load your data — ${errorMessage(error)}`);
      });

    return () => {
      cancelled = true;
    };
    // `pathname` is read only when loading fails (to know where to retry); it must not
    // restart a load already in progress.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [applySnapshot, checked, isLoaded, isSignedIn, request, showToast, userId]);

  // Dashboard progress comes from the backend (computed from saved data).
  const flags = profileProgress?.checklist ?? {
    companyDetailsDone: false,
    locationDone: false,
    certsDone: false,
    infraDone: false,
    faqDone: false,
  };
  const pct = profileProgress?.percentage ?? 15;

  async function handleAccountCreated(submission: AccountSubmission) {
    let snapshot: ServerSnapshot;
    try {
      snapshot = await request<ServerSnapshot>("/manufacturer/account", {
        method: "POST",
        body: JSON.stringify(submission),
      });
    } catch (error) {
      showToast(`Couldn’t create your account — ${errorMessage(error)}`);
      throw error; // lets AccountScreen re-enable the submit button
    }
    applySnapshot(snapshot);
    applyAccountSubmission(submission, setState, setProfileData);
    if (userId) setServer({ userId, accountExists: true, failed: false, approval: snapshot.approval ?? null });
    markManufacturerProfileComplete();
    router.push(MANUFACTURER_DASHBOARD_PATH);
    showToast(
      snapshot.approval?.access && !snapshot.approval.access.unlocked
        ? "Your manufacturer application is awaiting admin approval."
        : snapshot.submitted?.kind === "update_request"
          ? `Your update request for ${snapshot.submitted.companyName} was submitted for admin review.`
          : "Details sent to X!Y for approval.",
    );
  }

  /** Approval first: the remaining sections open only after X!Y approves (the backend refuses too). */
  function lockedMessage(profile: boolean): string | null {
    if (locked) return access?.message || "Your manufacturer application is awaiting admin approval.";
    if (profile && access && !access.canEditProfile) {
      return "Only the company's primary user can edit the shared company profile.";
    }
    return null;
  }

  function handleOpenProfileWizard(jumpToNextIncomplete: boolean) {
    const blocked = lockedMessage(true);
    if (blocked) {
      showToast(blocked);
      return;
    }
    // Continue from the last incomplete step saved in the backend.
    setProfileWizardStep(jumpToNextIncomplete ? (profileProgress?.resumeStep ?? 1) : 1);
    // The wizard starts from exactly these values, so changes are measured from them.
    savedProfile.current = profileData;
    setProfileWizardOpen(true);
  }

  const flushProfileSave = useCallback(() => {
    if (profileSaveTimer.current !== null) {
      window.clearTimeout(profileSaveTimer.current);
      profileSaveTimer.current = null;
    }
    const data = pendingProfile.current;
    if (!data) return;
    pendingProfile.current = null;

    profileSaveQueue.current = profileSaveQueue.current.then(async () => {
      // Send only what changed since the last successful save (PATCH): fields the
      // user didn't touch are never sent, so they can't overwrite saved values.
      const baseline = savedProfile.current ?? createBlankProfileData();
      const changes = diffProfile(baseline, data);
      if (!changes) return;
      try {
        const snapshot = await request<ServerSnapshot>("/manufacturer/profile", {
          method: "PATCH",
          body: JSON.stringify(changes),
        });
        savedProfile.current = data;
        // Newer edits waiting? Then they win; otherwise show the saved record.
        if (!pendingProfile.current) applySavedProfile(snapshot);
      } catch (error: unknown) {
        // Baseline is unchanged, so these fields are sent again with the next save.
        showToast(`Profile not saved — ${errorMessage(error)}`);
      }
    });
  }, [applySavedProfile, request, showToast]);

  /**
   * "Save & Next" / Skip / Previous in the profile wizard: PATCH the changed fields
   * of this step plus its progress, and resolve true only when the backend saved it.
   */
  const saveProfileStep = useCallback(
    (step: number, data: ProfileWizardData | null, progress: StepProgress): Promise<boolean> => {
      const task = async (): Promise<boolean> => {
        const changes = data ? diffProfile(savedProfile.current ?? createBlankProfileData(), data) : null;
        try {
          const snapshot = await request<ServerSnapshot>("/manufacturer/profile", {
            method: "PATCH",
            body: JSON.stringify({ ...(changes ?? {}), progress: { step, ...progress } }),
          });
          if (data) {
            savedProfile.current = data;
            pendingProfile.current = null;
          }
          applySavedProfile(snapshot);
          return true;
        } catch (error: unknown) {
          showToast(`Couldn’t save this step — ${errorMessage(error)}`);
          return false;
        }
      };
      // Runs after any save already in progress (strict order, no overlap).
      const result = profileSaveQueue.current.then(task);
      profileSaveQueue.current = result.then(() => undefined);
      return result;
    },
    [applySavedProfile, request, showToast],
  );

  function handleProfileChange(data: ProfileWizardData) {
    setProfileData(data);
    setState((current) => ({
      ...current,
      epic2: {
        companyDetailsDone: data.company.name.trim() !== "" && data.company.about.trim() !== "",
        locationDone:
          data.location.address.trim() !== "" &&
          data.location.city.trim() !== "" &&
          data.location.country !== "",
        certifications: data.certifications,
        infraDone: Object.values(data.infra).some((value) => value.trim() !== ""),
        faqs: data.faqs,
      },
      serviceableAreas: data.location.serviceableAreas,
    }));
    // Saved by the step buttons; remembered here so closing the wizard keeps it too.
    pendingProfile.current = data;
  }

  function openMachineryWizard() {
    const blocked = lockedMessage(false);
    if (blocked) {
      showToast(blocked);
      return;
    }
    // Continue an unfinished draft from the backend, or start a new one.
    const resume = machineryDraft;
    machinerySession.current = {
      id: resume?.id ?? null,
      clientKey: resume ? "" : crypto.randomUUID(),
      saved: resume?.data ?? null,
    };
    setMachineryStart({ draft: resume?.data ?? null, step: resume?.resumeStep ?? 1 });
    setMachineryWizardOpen(true);
  }

  function handleEditMachinery(machine: MachineryListing) {
  const serverId = ids.current.toServer.get(machine.id);

  if (!serverId) {
    showToast("Unable to edit this machinery.");
    return;
  }

  machinerySession.current = {
    id: serverId,
    clientKey: "",
    saved: machine as unknown as MachineryDraft,
  };

  setMachineryStart({
    draft: machine as unknown as MachineryDraft,
    step: 1,
  });

  setMachineryWizardOpen(true);
}

  /** One machinery request: first save creates the draft (POST), later ones PATCH it. */
  const sendMachinery = useCallback(
    async (draft: MachineryDraft | null, extra: Record<string, unknown>): Promise<ServerSnapshot> => {
      const session = machinerySession.current;
      if (!session.id) {
        if (!draft) throw new Error("Please fill in the machinery details first.");
        const { finish, ...createExtra } = extra;
        const created = await request<ServerSnapshot>("/manufacturer/machinery/drafts", {
          method: "POST",
          body: JSON.stringify({ clientKey: session.clientKey, ...draft, ...createExtra }),
        });
        session.id = created.machineryDraft?.id ?? null;
        session.saved = draft;
        if (!finish || !session.id) return created;
        // Publish / Save as Draft on a never-saved draft: create it, then complete it.
        extra = { finish };
      }
      const changes = draft ? diffFields(session.saved ?? draft, draft) : {};
      const snapshot = await request<ServerSnapshot>(`/manufacturer/machinery/${session.id}`, {
        method: "PATCH",
        body: JSON.stringify({ ...changes, ...extra }),
      });
      if (draft) session.saved = draft;
      return snapshot;
    },
    [request],
  );

  const saveMachineryStep = useCallback(
    async (step: number, draft: MachineryDraft | null, progress: StepProgress): Promise<boolean> => {
      try {
        const snapshot = await sendMachinery(draft, { progress: { step, ...progress } });
        setMachineryDraft(snapshot.machineryDraft);
        return true;
      } catch (error: unknown) {
        showToast(`Couldn’t save this step — ${errorMessage(error)}`);
        return false;
      }
    },
    [sendMachinery, showToast],
  );

  async function handleMachineryPublish(draft: MachineryDraft, status: "Draft" | "Published"): Promise<boolean> {
    try {
      // Save the last edits and complete the listing; close only when saved.
      const snapshot = await sendMachinery(draft, { finish: status });
      setState((current) => ({ ...current, machinery: toLocalMachinery(snapshot.state.machinery) }));
      setMachineryDraft(snapshot.machineryDraft);
      machinerySession.current = { id: null, clientKey: "", saved: null };
      setMachineryWizardOpen(false);
      showToast(status === "Published" ? "Listing published." : "Saved as draft.");
      return true;
    } catch (error: unknown) {
      showToast(`Listing not saved — ${errorMessage(error)}`);
      return false;
    }
  }

  function handleSetMachineryStatus(id: number, status: ManufacturerState["machinery"][number]["status"]) {
    setState((current) => ({
      ...current,
      machinery: current.machinery.map((m) => (m.id === id ? { ...m, status } : m)),
    }));
    showToast(`Listing status: ${status}.`);

    const serverId = ids.current.toServer.get(id);
    // Listing still being created: the create response restores its saved status.
    if (!serverId) return;
    request<ServerSnapshot>(`/manufacturer/machinery/${serverId}/status`, {
      method: "PATCH",
      body: JSON.stringify({ status }),
    }).catch((error: unknown) => {
      showToast(`Status not saved — ${errorMessage(error)}`);
      void resync();
    });
  }

  // Calendar day clicks: batched PATCH of the calendar only (recurring and
  // capacity are saved by their own Save buttons below and are never resent).
  useEffect(() => {
    if (!availabilityDirty.current) return;
    availabilityDirty.current = false;
    if (availabilityTimer.current !== null) window.clearTimeout(availabilityTimer.current);
    const body = JSON.stringify({ calendar: state.calendar });
    availabilityTimer.current = window.setTimeout(() => {
      availabilityTimer.current = null;
      request<ServerSnapshot>("/manufacturer/availability", { method: "PATCH", body }).catch(
        (error: unknown) => {
          showToast(`Availability not saved — ${errorMessage(error)}`);
        },
      );
    }, SAVE_DELAY_MS);
  }, [request, showToast, state.calendar]);

  /** Recurring / capacity Save: PATCH only that part; update the screen after it is saved. */
  async function saveAvailabilityPart(part: "recurring" | "capacity", value: unknown): Promise<boolean> {
    if (availabilitySaving.current) return false;       // ignore double clicks
    availabilitySaving.current = true;
    try {
      const snapshot = await request<ServerSnapshot>("/manufacturer/availability", {
        method: "PATCH",
        body: JSON.stringify({ [part]: value }),
      });
      setState((current) => ({ ...current, [part]: snapshot.state[part] }));
      return true;
    } catch (error: unknown) {
      showToast(`Availability not saved — ${errorMessage(error)}`);
      return false;
    } finally {
      availabilitySaving.current = false;
    }
  }

  // Send any pending profile edits before leaving the page.
  useEffect(() => {
    return () => {
      if (pendingProfile.current) flushProfileSave();
    };
  }, [flushProfileSave]);

  function handleCycleDay(key: string) {
    availabilityDirty.current = true;
    setState((current) => {
      const calendar = { ...current.calendar };
      const currentStatus = calendar[key];
      if (!currentStatus) {
        calendar[key] = "available";
      } else if (currentStatus === "available") {
        calendar[key] = "blocked";
      } else {
        delete calendar[key];
      }
      return { ...current, calendar };
    });
  }

  async function handleSaveCapacity(plan: ManufacturerState["capacity"]) {
    if (await saveAvailabilityPart("capacity", plan)) showToast("Capacity saved.");
  }

  async function handleSaveRecurring(recurring: RecurringAvailability) {
    if (!recurring.days.length || !recurring.start || !recurring.end) {
      showToast("Pick at least one day and a start/end time.");
      return;
    }
    if (await saveAvailabilityPart("recurring", recurring)) {
      setRecurringOpen(false);
      showToast("Recurring availability saved.");
    }
  }

  function decideBooking(id: number, decision: "accepted" | "declined") {
    const serverId = ids.current.toServer.get(id);
    if (!serverId) return;
    request<ServerSnapshot>(`/manufacturer/booking-requests/${serverId}`, {
      method: "PATCH",
      body: JSON.stringify({ status: decision }),
    })
      .then((snapshot) => {
        setState((current) => ({ ...current, bookings: toLocalBookings(snapshot.state.bookings) }));
      })
      .catch((error: unknown) => {
        showToast(`Booking not updated — ${errorMessage(error)}`);
        void resync();
      });
  }

  function handleAcceptBooking(id: number) {
    setState((current) => ({
      ...current,
      bookings: current.bookings.map((b) => (b.id === id ? { ...b, status: "Booked" } : b)),
    }));
    showToast("Booking confirmed.");
    decideBooking(id, "accepted");
  }

  function handleDeclineBooking(id: number) {
    setState((current) => ({
      ...current,
      bookings: current.bookings.map((b) => (b.id === id ? { ...b, status: "Cancelled" } : b)),
    }));
    showToast("Declined — capacity released back to Available.");
    decideBooking(id, "declined");
  }

  if (!isLoaded) {
    return <ManufacturerLoading />;
  }

  // Avoid flashing the wrong screen while redirects settle.
  if (!isSignedIn && (screen === "dashboard" || screen === "account")) {
    return <ManufacturerLoading />;
  }

  // Signed in: wait until the saved account has been checked (and any redirect has
  // happened) instead of briefly showing "Join Our Ecosystem" or the account form.
  if (isSignedIn) {
    const redirecting =
      checked &&
      !server.failed &&
      (screen === "dashboard" ? !server.accountExists : server.accountExists && !(screen === "account" && canResubmit));
    if (!checked || redirecting) {
      return <ManufacturerLoading />;
    }
  }

  return (
    <div className="mfg-root">
      {screen === "landing" ? (
        <LandingScreen
          onJoin={() => {
            // Signed-in → profile setup. Signed-out → existing Create Account.
            router.push(
              isSignedIn ? MANUFACTURER_ACCOUNT_PATH : manufacturerCreateAccountHref(),
            );
          }}
          onBackToLanding={() => {
            router.push("/");
          }}
        />
      ) : null}

      {screen === "account" ? (
  <AccountScreen
    onBack={() => {
      router.push(MANUFACTURER_OVERVIEW_PATH);
      window.scrollTo(0, 0);
    }}
    onAccountCreated={handleAccountCreated}
    onSearchCompanies={handleSearchCompanies}
    onLoadCompany={handleLoadCompany}
    correctionFields={access?.status === "changes_requested" ? access.application?.correctionFields : undefined}
    initial={server?.approval?.status === "changes_requested" || canReapply ? {
      ...state.account,
      // the user's own personal email; the phone is the company's
      email: state.account.personalEmail || "",
      phone: state.contact.phone || "",
      companyId: server?.approval?.kind === "new_company" ? null : server?.approval?.selectedCompanyId ?? null,
    } : requestToCorrect ? {
      // Correcting an update request: the user's own submitted values for that company.
      ...state.account,
      email: state.account.personalEmail || "",
      companyName: requestToCorrect.companyName,
      companyType: String(requestToCorrect.proposed.companyType ?? ""),
      country: String(requestToCorrect.proposed.country ?? ""),
      capacity: String(requestToCorrect.proposed.capacity ?? ""),
      phone: String(requestToCorrect.proposed.contactPhone ?? ""),
      companyId: requestToCorrect.companyId,
    } : registered ? {
      // New application: the user's own registration details (never another member's).
      firstName: registered.firstName,
      lastName: registered.lastName,
      email: registered.personalEmail || registered.email,
    } : undefined}
  />
) : null}

      {screen === "dashboard" ? (
        <>
          <DashboardScreen
            state={state}
            pct={pct}
            flags={flags}
            onOpenProfileWizard={handleOpenProfileWizard}
            onFixCompanyDetails={canResubmit ? () => router.push(MANUFACTURER_ACCOUNT_PATH) : undefined}
            lock={
              locked
                ? {
                    message: access?.message || "Your manufacturer application is awaiting admin approval.",
                    detail: access?.application?.feedback ? `X!Y: ${access.application.feedback}` : null,
                    actionLabel:
                      access?.status === "changes_requested"
                        ? "Correct details"
                        : canReapply
                          ? "Apply again"
                          : null,
                  }
                : null
            }
            profileLockedMessage={access && access.unlocked && !access.canEditProfile ? lockedMessage(true) : null}
            updateRequests={server?.approval?.updateRequests ?? []}
            onOpenMachineryWizard={openMachineryWizard}
            onEditMachinery={handleEditMachinery}
            onSetMachineryStatus={handleSetMachineryStatus}
            onSaveCapacity={handleSaveCapacity}
            onCycleDay={handleCycleDay}
            onOpenRecurringModal={() => setRecurringOpen(true)}
            onAcceptBooking={handleAcceptBooking}
            onDeclineBooking={handleDeclineBooking}
            onBackToLanding={() => {
              router.push("/");
            }}
            showToast={showToast}
          />

          {profileWizardOpen ? (
            <ProfileWizard
              firstName={state.account.firstName}
              flags={flags}
              pct={pct}
              initialStep={profileWizardStep}
              data={profileData}
              onChange={handleProfileChange}
              onExit={() => {
                setProfileWizardOpen(false);
                flushProfileSave();
              }}
              onFinish={() => undefined}
              showToast={showToast}
              onSaveStep={saveProfileStep}
            />
          ) : null}

          {machineryWizardOpen ? (
            <MachineryWizard
              onClose={() => setMachineryWizardOpen(false)}
              onPublish={handleMachineryPublish}
              showToast={showToast}
              onSaveStep={saveMachineryStep}
              initialDraft={machineryStart.draft}
              initialStep={machineryStart.step}
              hasSavedDraft={machineryDraft !== null}
            />
          ) : null}

          {recurringOpen ? (
  <RecurringModal
    initialValue={state.recurring}
    onClose={() => setRecurringOpen(false)}
    onSave={(days, start, end) =>
      void handleSaveRecurring({ days, start, end })
    }
  />
) : null}
        </>
      ) : null}

      <div className={`toast${toast.visible ? " show" : ""}`} role="status" aria-live="polite">
        <CheckIcon size={15} stroke="#4ade80" />
        <span>{toast.message}</span>
      </div>
    </div>
  );
}

/** Shown while the signed-in user's Manufacturer account is checked and loaded. */
function ManufacturerLoading() {
  return (
    <div className="mfg-root mfg-loading-screen" aria-busy="true">
      <div className="mfg-loading" role="status" aria-live="polite">
        <span className="mfg-spinner" aria-hidden="true" />
        <span>Loading your manufacturer account…</span>
      </div>
    </div>
  );
}

