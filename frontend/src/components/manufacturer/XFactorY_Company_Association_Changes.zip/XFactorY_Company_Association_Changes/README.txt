XFactorY - company association fix (changed files only)
=======================================================

This zip contains ALL changed files since the version you installed (the replaced backend\app,
backend\database and frontend\src folders): the approval-first changes from the previous zip
plus this fix. If you already applied the previous zip, copying this one over it is safe.
No CSS file changed and no new screen or separate registration process was added.

APPLY (Windows)
  1. Stop backend and frontend.
  2. Copy the "backend" and "frontend" folders from this zip over E:\Phaarvai\Workspace\XFactorY-FullStack.
  3. backend:  python -m app.migrate      (adds 025_approval_first.sql and 026_company_association.sql)
  4. Start backend and frontend.

WHERE THE ASSOCIATION WAS LOST
  The selected company's id was carried correctly from the form to the saved application
  (manufacturer_submissions.target_organization_id = the selected company's id). The problem was the
  per-user placeholder organization the app creates at sign-in (named after the person, no company
  details). After a user applied to join an existing company, that placeholder still appeared in the
  admin portal as a separate, nameless "company" (e.g. "Jansi Rani", no contact, no location); an admin
  could approve it there, which unlocked an empty record instead of approving the membership.

FIX
  - Migration 026: the admin overview (lists, review queue, counts, users' company column, Visionary
    eligibility) leaves out a placeholder that only exists for an application to another company.
  - Its admin page and review-status change are refused, pointing to the selected company instead.
  - A placeholder approved by mistake earlier does not unlock anything; only the application decides.
  - It is never offered in company search, and after approval the user's dashboard loads the
    selected company (same database id), with its saved details - nothing re-entered.
  - Company page -> Registered Users -> Other Users now also lists applicants awaiting approval
    ("Pending approval", with their personal email and application status; not counted as members).
    The application itself is reviewed in the company's "Update request" section, which shows the
    selected company's saved values next to the applicant's.
  - New companies: unchanged workflow; shown with the submitted name and details, record type Real.

TESTS
  Backend: 229 passed; the 12 failing tests also fail in the original project. New:
  tests\test_company_association.py (3) and tests\test_approval_first.py (10).
  Frontend: 231 passed; the 22 failing tests also fail in the original project.
  Do not deploy to production before testing on staging.
