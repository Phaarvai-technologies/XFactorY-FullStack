"""SQL for the Manufacturer frontend (src/components/manufacturer/*).

Every public method takes the frontend's own data shapes (camelCase keys from
`ManufacturerState` / `ProfileWizardData` / `MachineryDraft`) and maps them to
the canonical tables in XY_Database_Schema.sql (+ migrations 004-006).
"""
import hashlib
import json
import re
from datetime import date, datetime
from typing import Any
from uuid import UUID

from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app import company_update_requests as update_requests
from app import manufacturer_access as access
from app import manufacturer_approval as approval
from app.core.auth import Actor
from app.storage.supabase import DecodedImage, UploadedObject


COUNTRY_CODES = {
    "india": "IN", "united states": "US", "united kingdom": "GB", "united arab emirates": "AE",
    "germany": "DE", "china": "CN", "vietnam": "VN", "bangladesh": "BD",
}

# Frontend listing status  ->  (machines.status, machines.publication_status)
MACHINE_STATUS = {
    "Draft": ("active", "draft"),
    "Published": ("active", "published"),
    "Unpublished": ("active", "hidden"),
    "Archived": ("archived", "hidden"),
}

# Frontend infra keys -> infrastructure_items.category
INFRA_CATEGORIES = {
    "electricity": "electricity", "water": "water", "storage": "storage",
    "packaging": "packing", "waste": "waste_disposal", "qa": "quality_assurance",
}
INFRA_NAMES = {
    "electricity": "Electricity", "water": "Water", "storage": "Storage",
    "packaging": "Packaging", "waste": "Waste disposal", "qa": "Quality assurance",
}

# Booking statuses grouped the way the dashboard shows them.
OPEN_STATUSES = ("new", "returned")
RESERVED_STATUSES = ("accepted", "confirmation_pending")
BOOKED_STATUSES = ("confirmed", "booked")

# MachineryDraft keys that live on `machines`; everything else -> machine_specs.
MACHINE_COLUMN_KEYS = {"images", "type", "status", "technical"}


def slug(value: str) -> str:
    return re.sub(r"[^A-Z0-9]+", "_", value.upper()).strip("_")[:80] or "CUSTOM"


def capacity_number(value: Any) -> float | None:
    """'12,500 units/month' -> 12500.0 ; '' -> None."""
    if value in (None, ""):
        return None
    match = re.search(r"\d+(?:\.\d+)?", str(value).replace(",", ""))
    return float(match.group()) if match else None


def int_or_none(value: Any) -> int | None:
    value = str(value or "").strip()
    return int(value) if value.isdigit() else None


def parse_pin(pin: Any) -> tuple[float, float] | None:
    """Frontend pin format is 'lat, lng'."""
    if not isinstance(pin, str):
        return None
    parts = [p.strip() for p in pin.split(",")]
    if len(parts) != 2:
        return None
    try:
        lat, lng = float(parts[0]), float(parts[1])
    except ValueError:
        return None
    return (lat, lng) if -90 <= lat <= 90 and -180 <= lng <= 180 else None


def normalize_company_name(value: Any) -> str:
    """Comparison form of a company name: trimmed, inner whitespace collapsed, case-folded.
    Used for search and duplicate checks only; the stored name is never rewritten."""
    # lower() (not casefold) so Python and PostgreSQL lower() agree.
    return re.sub(r"\s+", " ", str(value or "")).strip().lower()


def _present(value: Any) -> bool:
    """None, "" and whitespace-only are missing; numbers (also 0) are values."""
    if value is None:
        return False
    return str(value).strip() != "" if isinstance(value, str) else True


def saved_company_values(r) -> dict:
    """An existing company's saved category, country, phone and capacity ("" = missing)."""
    def keep(value):
        return str(value).strip() if _present(value) else ""
    capacity = keep(r.get("production_capacity_label"))
    if not capacity and r.get("stated_production_capacity") is not None:
        number = float(r["stated_production_capacity"])
        capacity = str(int(number)) if number.is_integer() else f"{number:g}"
    return {"companyType": keep(r.get("company_category")),
            "country": keep(r.get("country_name")) or keep(r.get("facility_country")),
            "phone": keep(r.get("contact_phone")), "capacity": capacity}


def _same(key: str, sent: str, saved: str) -> bool:
    if key == "phone":
        from app.schemas.manufacturer import normalize_indian_phone
        try:
            return normalize_indian_phone(sent) == normalize_indian_phone(saved)
        except ValueError:
            return re.sub(r"\D", "", sent) == re.sub(r"\D", "", saved)
    return re.sub(r"\s+", " ", sent).strip().lower() == re.sub(r"\s+", " ", saved).strip().lower()


def _like_escape(value: str) -> str:
    """User text inside LIKE: % and _ are literal characters, not wildcards."""
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


# Every manufacturer organization is a selectable COMPANY for onboarding lookup - seeded /
# imported rows included, however they were loaded (entry_source may be the column default
# 'MANUFACTURER') - except an organization the app created for a user (created_by_user_id
# set) that is not an approved company yet: the empty per-user placeholder, or one whose
# details are still awaiting admin approval. Visionary visibility is a different rule
# (app/core/eligibility.py).
# A company the app created for a user (sign-up -> manufacturer onboarding) that an admin has not
# approved yet: the per-user placeholder, or details awaiting review / corrections / rejected.
# Imported and admin-added companies (no created_by_user_id) are never "awaiting approval".
# Also used by the admin Manufacturers list (app/admin/repository.py).
AWAITING_APPROVAL_SQL = """(o.created_by_user_id IS NOT NULL
             AND o.entry_source = 'MANUFACTURER'
             AND NOT EXISTS (SELECT 1 FROM manufacturer_onboarding mo
                             WHERE mo.organization_id = o.id
                               AND (mo.status = 'approved'
                                    -- accounts from before admin approval existed
                                    OR (mo.personal_information_completed
                                        AND NOT EXISTS (SELECT 1 FROM manufacturer_submissions s
                                                        WHERE s.organization_id = o.id
                                                          AND s.kind <> 'update_request')))))"""

LISTED_COMPANY_SQL = f"""
    o.organization_type = 'manufacturer'
    AND o.status IN ('active', 'claim_pending')
    AND NOT o.is_archived
    AND o.record_type <> 'TEST'
    AND NOT {AWAITING_APPROVAL_SQL}
    -- a user's placeholder for an application to another company is never a company itself
    AND NOT {access.applicant_workspace_sql("o")}
"""

# Who may update an organization through the onboarding form: its active owner / admin.
OWNER_ROLES_SQL = "('owner', 'admin')"


def profile_flags(data: dict) -> dict[str, bool]:
    """Same completion rules as ManufacturerApp.handleProfileChange."""
    c, loc = data["company"], data["location"]
    return {
        "company": bool(str(c.get("name") or "").strip() and str(c.get("about") or "").strip()),
        "location": bool(str(loc.get("address") or "").strip() and str(loc.get("city") or "").strip()
                         and loc.get("country")),
        "certs": bool(data.get("certifications")),
        "infra": any(str(v or "").strip() for v in (data.get("infra") or {}).values()),
        "faq": bool(data.get("faqs")),
    }



def _json_value(value):
    """A json column from the database: already decoded by the driver, or a JSON string."""
    return json.loads(value) if isinstance(value, (str, bytes)) else value

class ManufacturerRepository:
    def __init__(self, session: AsyncSession):
        self.db = session

    # ------------------------------------------------------------------ identity
    async def sync_actor(self, actor: Actor, profile: dict) -> None:
        """Create the user / organization / membership rows for a Clerk user."""
        if not profile.get("email"):
            raise LookupError("Your Clerk account has no primary email address")
        # One setup at a time per Clerk user: the roles page and the dashboard can
        # both trigger this at the same moment, and without the lock each request
        # could create its own manufacturer organization (duplicate records).
        await self.db.execute(text("SELECT pg_advisory_xact_lock(hashtextextended(:key, 0))"),
                              {"key": f"xy-sync-actor:{actor.clerk_user_id}"})
        try:
            user_id = await self.db.scalar(text("""
                INSERT INTO users(clerk_user_id,email,phone,display_name,first_name,last_name)
                VALUES (:clerk,:email,:phone,:display,NULLIF(:first,''),NULLIF(:last,''))
                ON CONFLICT (clerk_user_id) DO UPDATE SET email=EXCLUDED.email,
                  phone=COALESCE(users.phone,EXCLUDED.phone),
                  first_name=COALESCE(users.first_name,EXCLUDED.first_name),
                  last_name=COALESCE(users.last_name,EXCLUDED.last_name),
                  status=CASE WHEN users.status='suspended' THEN 'suspended' ELSE 'active' END,updated_at=now()
                RETURNING id
            """), {
                "clerk": actor.clerk_user_id, "email": profile["email"], "phone": profile.get("phone"),
                "display": f'{profile.get("first_name", "")} {profile.get("last_name", "")}'.strip() or profile["email"],
                "first": profile.get("first_name") or "", "last": profile.get("last_name") or "",
            })
        except IntegrityError as exc:
            await self.db.rollback()
            raise LookupError("This email is already linked to another account") from exc

        if actor.clerk_org_id:
            org_id = await self.db.scalar(text("""
                INSERT INTO organizations(clerk_organization_id,display_name,organization_type,status,created_by_user_id)
                VALUES (:clerk,:name,'manufacturer','active',:user)
                ON CONFLICT (clerk_organization_id) DO UPDATE SET status='active',updated_at=now()
                RETURNING id
            """), {"clerk": actor.clerk_org_id, "name": profile["organization_name"], "user": user_id})
        else:
            # The frontend has no Clerk Organization step, so each user gets a personal
            # manufacturer organization (clerk_organization_id stays NULL).
            org_id = await self.db.scalar(text("""
                SELECT o.id FROM organizations o
                JOIN memberships m ON m.organization_id=o.id AND m.user_id=:user AND m.status='active'
                WHERE o.organization_type='manufacturer' AND o.status<>'closed'
                ORDER BY (o.created_by_user_id=:user) DESC, m.created_at LIMIT 1
            """), {"user": user_id})
            if org_id is None:
                org_id = await self.db.scalar(text("""
                    INSERT INTO organizations(display_name,organization_type,status,created_by_user_id)
                    VALUES (:name,'manufacturer','active',:user) RETURNING id
                """), {"name": profile["organization_name"], "user": user_id})
        await self.db.execute(text("""
            INSERT INTO memberships(user_id,organization_id,membership_role,status,accepted_at)
            VALUES (:user,:org,'owner','active',now())
            ON CONFLICT (organization_id,user_id) DO UPDATE SET status='active'
        """), {"user": user_id, "org": org_id})
        await self.db.commit()

    async def context(self, actor: Actor) -> dict:
        base = """
            SELECT u.id user_id, u.first_name, u.last_name, u.date_of_birth, u.email, u.phone,
                   u.personal_email::text AS personal_email, u.status user_status,
                   o.id organization_id, o.display_name, o.organization_type, m.id membership_id
            FROM users u
            JOIN memberships m ON m.user_id=u.id AND m.status='active'
            JOIN organizations o ON o.id=m.organization_id
            WHERE u.clerk_user_id=:user
        """
        if actor.clerk_org_id:
            sql = base + " AND o.clerk_organization_id=:org"
        else:
            # The company whose details form was submitted wins over an empty placeholder
            # (matters when the user saved details to a company they own but did not create).
            # An approved company the user belongs to (e.g. joined after admin approval) wins next.
            # A placeholder kept only for an application to another company comes last.
            sql = base + f""" AND o.organization_type='manufacturer' AND o.status<>'closed'
                ORDER BY {access.applicant_workspace_sql("o")} ASC,
                         EXISTS (SELECT 1 FROM manufacturer_onboarding mo WHERE mo.organization_id=o.id
                                 AND mo.status='approved') DESC,
                         EXISTS (SELECT 1 FROM manufacturer_onboarding mo WHERE mo.organization_id=o.id
                                 AND mo.personal_information_completed) DESC,
                         (o.created_by_user_id=u.id) DESC, m.created_at LIMIT 1"""
        row = (await self.db.execute(text(sql), {"user": actor.clerk_user_id, "org": actor.clerk_org_id})).first()
        if not row:
            raise LookupError("Clerk user/organization is not synchronized yet")
        result = dict(row._mapping)
        if result.pop("user_status") != "active":
            raise PermissionError("This account has been suspended. Please contact X!Y support.")
        if result["organization_type"] != "manufacturer":
            raise PermissionError("Active organization is not a Manufacturer")
        return result

    async def context_for_org(self, organization_id: str) -> dict:
        """Context for admin work on one manufacturer: the organization plus its
        owner's user record (for display). membership_id is None, so rows an admin
        writes are not attributed to the manufacturer's own membership."""
        row = (await self.db.execute(text("""
            SELECT u.id user_id, u.first_name, u.last_name, u.date_of_birth, u.email, u.phone,
                   o.id organization_id, o.display_name, o.organization_type, CAST(NULL AS uuid) membership_id
            FROM organizations o
            LEFT JOIN LATERAL (
              SELECT m.user_id FROM memberships m WHERE m.organization_id=o.id AND m.status='active'
              ORDER BY (m.membership_role='owner') DESC, m.created_at LIMIT 1) own ON true
            LEFT JOIN users u ON u.id=own.user_id
            WHERE o.id=CAST(:org AS uuid) AND o.organization_type='manufacturer'
        """), {"org": organization_id})).first()
        if not row:
            raise LookupError("Manufacturer not found")
        return dict(row._mapping)

    async def user_id_for(self, clerk_user_id: str) -> UUID | None:
        return await self.db.scalar(text("SELECT id FROM users WHERE clerk_user_id=:c"), {"c": clerk_user_id})

    async def touch_last_seen(self, clerk_user_id: str) -> None:
        """Last activity for the admin Users / Support pages (at most every 5 minutes)."""
        await self.db.execute(text("""
            UPDATE users SET last_seen_at=now()
            WHERE clerk_user_id=:c AND (last_seen_at IS NULL OR last_seen_at < now() - interval '5 minutes')
        """), {"c": clerk_user_id})
        await self.db.commit()

    async def _country_code(self, name: str) -> str | None:
        code = COUNTRY_CODES.get((name or "").strip().lower())
        if code and await self.db.scalar(text("SELECT 1 FROM countries WHERE code=:c"), {"c": code}):
            return code
        return None

    # ------------------------------------------------------------------ account
    async def create_account(self, actor: Actor, data: dict, settings=None) -> dict:
        """Manufacturer onboarding form. The user is identified by the Clerk user id
        (via `context`); the existing user / organization rows are updated in place.

        First and last name arrive prefilled from the saved user record: they are
        written only if the user changed them, so unchanged values are preserved.
        Returns {"names_changed": bool} so the caller can sync Clerk."""
        ctx = await self.context(actor)
        # One onboarding save at a time per user (double submit -> no duplicate rows).
        await self.db.execute(text("SELECT pg_advisory_xact_lock(hashtextextended(:k, 0))"),
                              {"k": f"xy-account:{ctx['user_id']}"})
        workspace = ctx["organization_id"]
        # Approval-first: a rejected applicant may apply again only after the waiting period
        # (app/manufacturer_access.py). Approved users are not affected.
        current = await access.state(self.db, ctx, settings)
        if not current["unlocked"]:
            await access.check_reapply(self.db, ctx["user_id"], settings)
        previous_app = await access.latest_application(self.db, ctx["user_id"])
        target = await self._account_target(ctx, data)
        # Personal email of the registering user (validated by AccountPayload): saved on the user
        # only, never as the company's contact email.
        personal_email = (data.get("email") or "").strip()
        # Company information: an existing company's saved values are kept as they are (a value
        # that differs is refused); only fields it does not have yet may be supplied.
        company = await self._company_values(target, data)
        contact_phone = company["phone"]
        country = await self._country_code(company["country"])
        first, last = data["firstName"].strip(), data["lastName"].strip()
        dob = data.get("dob") or None  # optional
        applicant = {"firstName": first, "lastName": last, "personalEmail": personal_email,
                     "dob": access.dob_text(dob)}
        # Corrections requested: only the fields the admin listed may change.
        await access.check_corrections(self.db, ctx["user_id"], {
            **applicant, "company": str(target["organization_id"]) if target["selected"] else "",
            "companyName": target["name"] if target["selected"] else data["companyName"].strip(),
            "companyType": company["companyType"], "country": company["country"],
            "companyPhone": contact_phone, "capacity": company["capacity"]})
        # Personal details belong to the user and are saved directly (not company data).
        names_changed = (await self.db.execute(text("""
            UPDATE users SET first_name=:first, last_name=:last, display_name=:display, updated_at=now()
            WHERE id=:user_id AND (first_name IS DISTINCT FROM CAST(:first AS text)
                                   OR last_name IS DISTINCT FROM CAST(:last AS text))
            RETURNING id
        """), {**ctx, "first": first, "last": last, "display": f"{first} {last}"})).first() is not None
        # users.email stays the Clerk sign-in email; the form's email is the user's PERSONAL email.
        # The company phone belongs to the company and is never written to the user.
        await self.db.execute(text("""
            UPDATE users SET date_of_birth=CAST(:dob AS date), personal_email=CAST(:pemail AS citext),
              updated_at=now()
            WHERE id=:user_id
              AND (date_of_birth IS DISTINCT FROM CAST(:dob AS date)
                   OR personal_email IS DISTINCT FROM CAST(:pemail AS citext))
        """), {**ctx, "dob": date.fromisoformat(str(dob)) if dob else None, "pemail": personal_email})
        # Company details go to staging until an admin approves them (app/manufacturer_approval.py).
        payload = {
            "companyName": (target["name"] if target["selected"] else data["companyName"].strip()),
            "companyType": company["companyType"], "country": company["country"], "countryCode": country,
            "capacity": company["capacity"], "capacityNumber": capacity_number(company["capacity"]),
            # the company's contact email is never taken from the registering user's personal email
            "contactEmail": None, "contactPhone": contact_phone,
            # the applicant's own personal information (shown to admins; corrections compare it)
            "applicant": applicant,
        }
        if target["kind"] == "update_request":
            try:
                request = await update_requests.submit(
                    self.db, user_id=ctx["user_id"], workspace_id=workspace,
                    company_id=target["organization_id"], payload=payload)
            except update_requests.RequestError as exc:
                raise ValueError(str(exc)) from exc
        else:
            request = None
            await approval.stage(self.db, user_id=ctx["user_id"], workspace_id=workspace,
                                 target_id=target["organization_id"],
                                 selected_id=target["organization_id"] if target["selected"] else None,
                                 kind=target["kind"], payload=payload)
        await self.db.execute(text("""
            INSERT INTO marketplace_role_selections(user_id,role_selected)
            SELECT :user_id,'manufacturer' WHERE NOT EXISTS (
              SELECT 1 FROM marketplace_role_selections
              WHERE user_id=:user_id AND role_selected='manufacturer' AND status='active')
        """), ctx)
        # The workspace (the user's own organization) is where they keep building the profile
        # while the review runs. A new company is now awaiting approval ('submitted');
        # completing the profile never changes this status.
        await self.db.execute(text("""
            INSERT INTO manufacturer_onboarding
              (organization_id,current_step,personal_information_completed,completion_percentage,status,submitted_at)
            VALUES (:organization_id,'company_information',true,15,
                    CASE WHEN :new THEN 'submitted' ELSE 'in_progress' END, CASE WHEN :new THEN now() END)
            ON CONFLICT (organization_id) DO UPDATE SET personal_information_completed=true,
              completion_percentage=GREATEST(manufacturer_onboarding.completion_percentage,15),
              status=CASE WHEN manufacturer_onboarding.status='approved' THEN 'approved'
                          WHEN :new THEN 'submitted'
                          WHEN manufacturer_onboarding.status='draft' THEN 'in_progress'
                          ELSE manufacturer_onboarding.status END,
              submitted_at=CASE WHEN :new AND manufacturer_onboarding.status<>'approved' THEN now()
                                ELSE manufacturer_onboarding.submitted_at END,
              version=manufacturer_onboarding.version+1
        """), {**ctx, "organization_id": workspace, "new": target["kind"] == "new_company"})
        await self.db.commit()
        submitted = {"kind": target["kind"], "companyId": str(target["organization_id"]),
                     "companyName": target["name"] or payload["companyName"],
                     "requestId": str(request["id"]) if request else None,
                     # for the admin notice: an application sent again (corrections / retry)
                     "resubmitted": bool(previous_app and previous_app["status"] in approval.OPEN),
                     "applicant": f"{first} {last}".strip()}
        return {"names_changed": names_changed, "submitted": submitted}

    async def _company_values(self, target: dict, data: dict) -> dict:
        """Company information for the submission.

        * New company: the form's values (validated by AccountPayload; phone normalized to +91).
        * Existing company (selected by database id): its SAVED values are shown read-only on the
          form and are never overwritten by the registering user:
            - claim of an unowned company: saved values are used as they are; only fields the
              company does not have (null / empty / whitespace - a saved 0 is a value) take the
              submitted value, and on approval only missing fields are filled;
            - a company managed by someone else / the owner's own company: the existing
              admin-reviewed update process - nothing changes unless an X!Y admin approves.
          The company phone is required: the saved one, or a valid Indian number."""
        from app.schemas.manufacturer import normalize_indian_phone

        sent = {"companyType": (data.get("companyType") or "").strip(), "country": (data.get("country") or "").strip(),
                "phone": (data.get("phone") or "").strip(), "capacity": (data.get("capacity") or "").strip()}
        if not target["selected"]:
            return sent
        r = (await self.db.execute(text("""
            SELECT op.company_category, op.country_name, op.contact_phone, op.production_capacity_label,
                   op.stated_production_capacity,
                   (SELECT f.country_name FROM facilities f WHERE f.organization_id = o.id AND f.is_headquarters
                      AND f.status <> 'suspended' LIMIT 1) AS facility_country
            FROM organizations o LEFT JOIN organization_profiles op ON op.organization_id = o.id
            WHERE o.id = :id
        """), {"id": target["organization_id"]})).mappings().first() or {}
        saved = saved_company_values(r)
        if target["kind"] == "claim":
            out = {k: (saved[k] or sent[k]) for k in sent}
        else:
            out = dict(sent)
        if out["phone"] and saved["phone"] and _same("phone", out["phone"], saved["phone"]):
            out["phone"] = saved["phone"]  # the saved number, as stored
        elif out["phone"]:
            out["phone"] = normalize_indian_phone(out["phone"])  # a supplied / proposed number: Indian
        elif not out["phone"]:
            if not saved["phone"]:
                raise ValueError("Company phone number is required")
            out["phone"] = saved["phone"]
        return out

    async def _account_target(self, ctx: dict, data: dict) -> dict:
        """Which organization the Manufacturer details form may write to, checked BEFORE any
        write (inside the caller's transaction, row locked):

        * a selected company (companyId): must exist and be listed, the submitted name must be
          that record's name. Its active owner / admin updates it (staged for approval); an
          unowned company may be claimed; a company managed by someone else gets an update
          request for admin review. Selecting never grants ownership, and nothing on an unowned
          or someone else's company changes before an admin approves;
        * no selection: a NEW company on the user's own organization, refused when a listed
          company with the same name already exists in the same country (similar names in
          different locations stay separate; records are never merged by name).
        """
        company_id = data.get("companyId")
        if company_id:
            # Lock the company row first; ownership is read AFTER the lock is granted (a new
            # statement sees a claim committed meanwhile - in one statement it would not).
            locked = (await self.db.execute(text(f"""
                SELECT o.id, o.display_name FROM organizations o
                WHERE o.id = CAST(:company_id AS uuid) AND {LISTED_COMPANY_SQL}
                FOR UPDATE OF o
            """), {"company_id": str(company_id)})).first()
            row = None if locked is None else (await self.db.execute(text(f"""
                SELECT CAST(:id AS uuid) AS id, CAST(:name AS text) AS display_name,
                       EXISTS (SELECT 1 FROM memberships m WHERE m.organization_id=CAST(:id AS uuid)
                               AND m.user_id=:user_id AND m.status='active'
                               AND m.membership_role IN {OWNER_ROLES_SQL}) AS mine,
                       EXISTS (SELECT 1 FROM memberships m WHERE m.organization_id=CAST(:id AS uuid)
                               AND m.status='active' AND m.membership_role IN {OWNER_ROLES_SQL}) AS claimed
            """), {"id": locked.id, "name": locked.display_name, "user_id": ctx["user_id"]})).first()
            if row is None:
                raise LookupError("The selected company was not found. Please search again.")
            if normalize_company_name(row.display_name) != normalize_company_name(data["companyName"]):
                raise ValueError("The company name does not match the selected company. Select it again from the list.")
            if row.mine or row.id == ctx["organization_id"]:
                approved = await approval.approval_status(self.db, row.id) == "approved"
                kind = "update" if approved else ("new_company" if row.id == ctx["organization_id"] else "update")
                return {"organization_id": row.id, "selected": True, "kind": kind, "name": row.display_name}
            if row.claimed:
                # Managed by someone else: the details become an update request for X!Y admin
                # review (app/company_update_requests.py). Nothing on the company changes now,
                # and the request never grants ownership or membership.
                return {"organization_id": row.id, "selected": True, "kind": "update_request",
                        "name": row.display_name}
            # Unclaimed (seeded / imported, no owner): the user may submit a claim; it takes effect
            # only when an admin approves it. One claim at a time per company (row locked above).
            other_claim = await self.db.scalar(text("""
                SELECT 1 FROM manufacturer_submissions WHERE target_organization_id = :t AND kind = 'claim'
                  AND status IN ('pending', 'changes_requested') AND submitted_by_user_id <> :u LIMIT 1
            """), {"t": row.id, "u": ctx["user_id"]})
            if other_claim:
                raise LookupError("Another request to manage this company is already awaiting X!Y review.")
            return {"organization_id": row.id, "selected": True, "kind": "claim", "name": row.display_name}

        name = normalize_company_name(data["companyName"])
        country = str(data.get("country") or "").strip().lower()
        # Serialize creations of the same name + country (two users at the same moment).
        await self.db.execute(text("SELECT pg_advisory_xact_lock(hashtextextended(:k, 0))"),
                              {"k": f"xy-company:{name}|{country}"})
        clash = await self.db.scalar(text(f"""
            SELECT o.id FROM organizations o
            LEFT JOIN organization_profiles op ON op.organization_id = o.id
            LEFT JOIN facilities f ON f.organization_id = o.id AND f.is_headquarters AND f.status <> 'suspended'
            WHERE {LISTED_COMPANY_SQL} AND o.id <> :organization_id
              AND lower(regexp_replace(btrim(o.display_name), '\\s+', ' ', 'g')) = :name
              AND lower(btrim(COALESCE(op.country_name, f.country_name, ''))) = :country
            LIMIT 1
        """), {"organization_id": ctx["organization_id"], "name": name, "country": country})
        if clash is None:
            # Another user's company with this name + country may still be awaiting approval.
            clash = await self.db.scalar(text("""
                SELECT 1 FROM manufacturer_submissions s
                WHERE s.status IN ('pending', 'changes_requested') AND s.kind = 'new_company'
                  AND s.submitted_by_user_id <> :user_id
                  AND lower(regexp_replace(btrim(s.payload->>'companyName'), '\\s+', ' ', 'g')) = :name
                  AND lower(btrim(COALESCE(s.payload->>'country', ''))) = :country
                LIMIT 1
            """), {"user_id": ctx["user_id"], "name": name, "country": country})
        if clash is not None:
            raise LookupError("A company with this name is already registered in this country. "
                              "Select it from the list, or check the name and country.")
        approved = await approval.approval_status(self.db, ctx["organization_id"]) == "approved"
        return {"organization_id": ctx["organization_id"], "selected": False,
                "kind": "update" if approved else "new_company", "name": None}

    # ------------------------------------------------------------------ company search
    async def search_companies(self, query: str, user_id: UUID | None = None, limit: int = 10) -> list[dict]:
        """Listed manufacturer companies matching `query` (trimmed, case-insensitive), read live
        from the database. Exact name first, then names starting with the text, then names with
        a word starting with it, then other partial matches. Location is returned so companies
        with similar names can be told apart; no contact details are exposed."""
        query = re.sub(r"\s+", " ", query or "").strip()
        if len(query) < 2:
            return []
        q = query.lower()
        rows = await self.db.execute(text(f"""
            WITH matches AS (
              SELECT o.id, o.display_name, lower(regexp_replace(btrim(o.display_name), '\\s+', ' ', 'g')) AS norm,
                     op.country_name AS profile_country, op.company_category,
                     f.city, f.state_province, f.country_name AS facility_country,
                     EXISTS (SELECT 1 FROM memberships m WHERE m.organization_id=o.id AND m.status='active'
                             AND m.membership_role IN {OWNER_ROLES_SQL}) AS claimed,
                     EXISTS (SELECT 1 FROM memberships m WHERE m.organization_id=o.id AND m.status='active'
                             AND m.user_id = :user_id AND m.membership_role IN {OWNER_ROLES_SQL}) AS mine
              FROM organizations o
              LEFT JOIN organization_profiles op ON op.organization_id = o.id
              LEFT JOIN LATERAL (
                SELECT city, state_province, country_name FROM facilities
                WHERE organization_id = o.id AND is_headquarters AND status <> 'suspended' LIMIT 1) f ON true
              WHERE {LISTED_COMPANY_SQL}
                AND (lower(regexp_replace(btrim(o.display_name), '\\s+', ' ', 'g')) LIKE :contains ESCAPE '\\'
                     OR lower(regexp_replace(btrim(COALESCE(o.legal_name, '')), '\\s+', ' ', 'g'))
                        LIKE :contains ESCAPE '\\')
            )
            SELECT *, CASE WHEN norm = :q THEN 0
                           WHEN norm LIKE :prefix ESCAPE '\\' THEN 1
                           WHEN norm LIKE :word ESCAPE '\\' THEN 2
                           ELSE 3 END AS rank
            FROM matches
            ORDER BY rank, norm, display_name, id
            LIMIT :limit
        """), {"q": q, "contains": f"%{_like_escape(q)}%", "prefix": f"{_like_escape(q)}%",
                "word": f"% {_like_escape(q)}%", "user_id": user_id, "limit": max(1, min(limit, 10))})
        return [{
            "id": str(r.id),
            "companyName": r.display_name,
            "country": r.profile_country or r.facility_country,
            "city": r.city,
            "state": r.state_province,
            "companyType": r.company_category,
            "claimed": bool(r.claimed),
            "ownedByYou": bool(r.mine),
        } for r in rows]

    async def company_details(self, company_id: str, user_id: UUID) -> dict:
        """Saved details of exactly this company record, for prefilling the details form.
        Contact details are returned only to the company's own owner / admin."""
        r = (await self.db.execute(text(f"""
            SELECT o.id, o.display_name, op.company_category, op.country_name, op.production_capacity_label,
                   op.stated_production_capacity,
                   op.contact_phone, f.city, f.state_province, f.country_name AS facility_country,
                   EXISTS (SELECT 1 FROM memberships m WHERE m.organization_id=o.id AND m.status='active'
                           AND m.membership_role IN {OWNER_ROLES_SQL}) AS claimed,
                   EXISTS (SELECT 1 FROM memberships m WHERE m.organization_id=o.id AND m.status='active'
                           AND m.user_id=:user_id AND m.membership_role IN {OWNER_ROLES_SQL}) AS mine
            FROM organizations o
            LEFT JOIN organization_profiles op ON op.organization_id = o.id
            LEFT JOIN LATERAL (
              SELECT city, state_province, country_name FROM facilities
              WHERE organization_id = o.id AND is_headquarters AND status <> 'suspended' LIMIT 1) f ON true
            WHERE o.id = CAST(:id AS uuid) AND {LISTED_COMPANY_SQL}
        """), {"id": company_id, "user_id": user_id})).first()
        if r is None:
            raise LookupError("Company not found")
        access = "owner" if r.mine else ("claimed" if r.claimed else "unclaimed")
        saved = saved_company_values(dict(r._mapping))
        return {
            "id": str(r.id),
            "companyName": r.display_name,
            "companyType": saved["companyType"],
            "country": saved["country"],
            "city": r.city or "",
            "state": r.state_province or "",
            "capacity": saved["capacity"],
            # the company's own phone (business information), shown read-only on the onboarding form
            "phone": saved["phone"],
            # saved fields are read-only on the onboarding form; these may be supplied (missing on record)
            "missing": [k for k, v in saved.items() if not v],
            "access": access,
            # owner: may update (admin-reviewed); unclaimed: may complete missing details
            "canUpdate": bool(r.mine) or not r.claimed,
        }

    async def fill_missing_names(self, ctx: dict, first: str | None, last: str | None) -> None:
        """Copy the name from Clerk into the user record when the record has none
        (never overwrites a saved name)."""
        await self.db.execute(text("""
            UPDATE users SET first_name=COALESCE(first_name, NULLIF(:first,'')),
              last_name=COALESCE(last_name, NULLIF(:last,'')), updated_at=now()
            WHERE id=:user_id AND (first_name IS NULL OR last_name IS NULL)
        """), {**ctx, "first": (first or "").strip(), "last": (last or "").strip()})
        await self.db.commit()

    # ------------------------------------------------------------------ files
    async def find_file(self, ctx: dict, image: DecodedImage, purpose: str) -> UUID | None:
        """Reuse an identical image this organization already uploaded.

        The profile wizard re-sends the same logo/cover data URL on every save,
        so this prevents duplicate uploads.
        """
        return await self.db.scalar(text("""
            SELECT id FROM files
            WHERE organization_id=:organization_id AND checksum=:checksum AND purpose=:purpose AND status='active'
            ORDER BY created_at DESC LIMIT 1
        """), {**ctx, "checksum": image.checksum, "purpose": purpose})

    async def add_file(self, ctx: dict, uploaded: UploadedObject, purpose: str) -> UUID:
        file_id = await self.db.scalar(text("""
            INSERT INTO files
              (organization_id,uploaded_by_user_id,object_key,filename,content_type,size_bytes,
               checksum,classification,scan_status,purpose)
            VALUES (:organization_id,:user_id,:key,:filename,:content_type,:size,:checksum,'public','clean',:purpose)
            RETURNING id
        """), {**ctx, "key": uploaded.object_key, "filename": uploaded.filename,
                "content_type": uploaded.content_type, "size": uploaded.size_bytes,
                "checksum": uploaded.checksum, "purpose": purpose})
        await self.db.commit()
        return file_id

    # ------------------------------------------------------------------ profile
    # Frontend field -> (table, column). Only these columns can be written, so
    # the dynamic UPDATEs below never take a column name from the request.
    COMPANY_PROFILE_COLUMNS = {
        "about": "about_company", "vision": "vision", "estYear": "establishment_year",
        "employees": "employee_count", "businessType": "business_type", "orgSize": "organization_size",
    }
    LOCATION_COLUMNS = {
        "address": ("address", "address_line1"), "city": ("city",), "state": ("state_province",),
        "zip": ("postal_code",), "sez": ("sez_status",),
    }

    async def update_profile(self, actor: Actor | None, changes: dict, asset_ids: dict[str, UUID | None],
                             commit: bool = True, ctx: dict | None = None) -> None:
        """Partial update of the manufacturer profile (PATCH semantics).

        `changes` holds ONLY the fields the user changed:
          key absent        -> column untouched (existing value or NULL stays)
          key = "" / null   -> user cleared it -> NULL
          key = value       -> saved (replaces an existing value or a NULL)
        The record is identified by the Clerk user's manufacturer organization;
        existing rows are updated in place, never duplicated.
        """
        ctx = ctx or await self.context(actor)
        company = changes.get("company") or {}
        location = changes.get("location")

        # organizations: display_name is required, so an empty name is ignored
        # (the company keeps its name); description mirrors "about".
        org_sets, org_params = [], {}
        if str(company.get("name") or "").strip():
            # The company name requires admin review: staged, not written (older accounts that
            # never submitted keep the previous direct behaviour).
            if not await approval.stage_name_change(self.db, user_id=ctx["user_id"],
                                                    workspace_id=ctx["organization_id"],
                                                    name=company["name"].strip()):
                org_sets.append("display_name=:name"); org_params["name"] = company["name"].strip()
        if "about" in company:
            org_sets.append("description=:about"); org_params["about"] = company["about"] or None
        if org_sets:
            await self.db.execute(text(
                f"UPDATE organizations SET {', '.join(org_sets)}, updated_at=now(), version=version+1 "
                "WHERE id=:organization_id"), {**ctx, **org_params})

        # organization_profiles: one row per organization (primary key), upserted.
        profile_values: dict[str, Any] = {}
        for key, column in self.COMPANY_PROFILE_COLUMNS.items():
            if key in company:
                value = company[key]
                if key in ("estYear", "employees"):
                    value = int(value) if str(value or "").strip() else None
                profile_values[column] = value if value not in ("",) else None
        for key in ("logo", "cover"):
            if key in asset_ids:  # new image uploaded, or cleared (None)
                profile_values[f"{key}_file_id"] = asset_ids[key]
        if profile_values:
            cols = list(profile_values)
            await self.db.execute(text(
                f"INSERT INTO organization_profiles (organization_id, {', '.join(cols)}) "
                f"VALUES (:organization_id, {', '.join(':' + c for c in cols)}) "
                f"ON CONFLICT (organization_id) DO UPDATE SET "
                f"{', '.join(f'{c}=EXCLUDED.{c}' for c in cols)}, updated_at=now()"),
                {**ctx, **profile_values})

        needs_facility = location is not None or any(k in changes for k in ("certifications", "infra", "faqs"))
        facility_id = await self._ensure_facility(ctx, company.get("name")) if needs_facility else None

        if location:
            sets, params = [], {"facility": facility_id}
            for key, columns in self.LOCATION_COLUMNS.items():
                if key in location:
                    params[key] = location[key] or None
                    sets += [f"{column}=:{key}" for column in columns]
            if "country" in location:
                params["country_name"] = location["country"] or None
                params["country_code"] = await self._country_code(location["country"] or "")
                sets += ["country_name=:country_name", "country_code=:country_code"]
            if "serviceableAreas" in location:
                params["areas"] = list(location["serviceableAreas"] or [])  # NOT NULL column: cleared = []
                sets.append("serviceable_areas=:areas")
            if "pin" in location:
                coords = parse_pin(location["pin"])
                params.update(pin=location["pin"] or None,
                              lat=coords[0] if coords else None, lng=coords[1] if coords else None)
                sets += ["map_pin=:pin",
                         "location=CASE WHEN CAST(:lat AS float8) IS NULL THEN NULL ELSE "
                         "ST_SetSRID(ST_MakePoint(CAST(:lng AS float8),CAST(:lat AS float8)),4326)::geography END"]
            if sets:
                await self.db.execute(text(
                    f"UPDATE facilities SET {', '.join(sets)}, version=version+1 WHERE id=:facility"), params)

        if "certifications" in changes:
            await self._replace_certifications(ctx, facility_id, changes["certifications"] or [])
        if "infra" in changes:
            await self._replace_infrastructure(ctx, facility_id, changes["infra"] or {})
        if "faqs" in changes:
            await self._replace_faqs(ctx, facility_id, changes["faqs"] or [])
        if commit:
            await self.db.commit()

    async def _ensure_facility(self, ctx: dict, company_name: str | None) -> UUID:
        """The manufacturer's single headquarters facility (created once, then reused)."""
        facility_id = await self.db.scalar(text("""
            SELECT id FROM facilities WHERE organization_id=:organization_id
              AND is_headquarters=true AND status<>'suspended' LIMIT 1
        """), ctx)
        if facility_id:
            return facility_id
        return await self.db.scalar(text("""
            INSERT INTO facilities (organization_id,name,facility_type,is_headquarters,status,visibility)
            VALUES (:organization_id,:name,'factory',true,'draft','private')
            ON CONFLICT (organization_id) WHERE is_headquarters=true AND status<>'suspended'
            DO UPDATE SET version=facilities.version RETURNING id
        """), {**ctx, "name": f'{(company_name or "").strip() or ctx["display_name"] or "Manufacturer"} Headquarters'})

    async def set_onboarding_flags(self, actor: Actor | None, flags: dict[str, bool], ctx: dict | None = None) -> None:
        """Also moves the review status: a profile with every section complete becomes
        SUBMITTED (including after an admin's "Needs correction"); REVIEWED stays."""
        ctx = ctx or await self.context(actor)
        complete = all(flags.values())
        pct = round(15 + sum(flags.values()) / 5 * 85)
        steps = [("company", "company_information"), ("location", "location"), ("certs", "certification"),
                 ("infra", "infrastructure"), ("faq", "faq")]
        next_step = next((step for key, step in steps if not flags[key]), "completed")
        await self.db.execute(text("""
            INSERT INTO manufacturer_onboarding
              (organization_id,current_step,company_information_completed,location_completed,
               certification_completed,infrastructure_completed,faq_completed,completion_percentage,status)
            VALUES (:organization_id,:step,:company,:location,:certs,:infra,:faq,:pct,'in_progress')
            ON CONFLICT (organization_id) DO UPDATE SET current_step=EXCLUDED.current_step,
              company_information_completed=EXCLUDED.company_information_completed,
              location_completed=EXCLUDED.location_completed,
              certification_completed=EXCLUDED.certification_completed,
              infrastructure_completed=EXCLUDED.infrastructure_completed,
              faq_completed=EXCLUDED.faq_completed,completion_percentage=EXCLUDED.completion_percentage,
              -- Profile completion never changes the approval status. Only accounts from before
              -- admin approval existed (no submission) keep "complete = submitted for review".
              status=CASE
                WHEN :complete AND manufacturer_onboarding.status IN ('draft','in_progress','changes_requested')
                     AND NOT EXISTS (SELECT 1 FROM manufacturer_submissions s
                                     WHERE s.organization_id = manufacturer_onboarding.organization_id)
                  THEN 'submitted'
                WHEN manufacturer_onboarding.status='draft' THEN 'in_progress'
                ELSE manufacturer_onboarding.status END,
              submitted_at=CASE
                WHEN :complete AND manufacturer_onboarding.status IN ('draft','in_progress','changes_requested')
                     AND NOT EXISTS (SELECT 1 FROM manufacturer_submissions s
                                     WHERE s.organization_id = manufacturer_onboarding.organization_id)
                  THEN now() ELSE manufacturer_onboarding.submitted_at END,
              version=manufacturer_onboarding.version+1
        """), {**ctx, **flags, "step": next_step, "pct": pct, "complete": complete})
        await self.db.commit()

    async def _replace_certifications(self, ctx: dict, facility_id: UUID, items: list[dict]) -> None:
        # Reviewed certifications are kept; self-declared ones mirror the wizard list.
        reviewed = {
            (r.name, r.body or "") for r in (await self.db.execute(text("""
                SELECT ct.name, oc.issuer body FROM organization_certifications oc
                JOIN certification_types ct ON ct.id=oc.certification_type_id
                WHERE oc.organization_id=:organization_id AND oc.status<>'declared'
            """), ctx))
        }
        await self.db.execute(text(
            "DELETE FROM organization_certifications WHERE organization_id=:organization_id AND status='declared'"
        ), ctx)
        for item in items:
            name = str(item.get("name") or "").strip()
            body = str(item.get("body") or "").strip()
            if not name or (name, body) in reviewed:
                continue
            cert_type = await self._certification_type(name, body)
            await self.db.execute(text("""
                INSERT INTO organization_certifications
                  (organization_id,facility_id,certification_type_id,issuer,document_file_name,status,created_at)
                VALUES (:organization_id,:facility,:type,:issuer,:file_name,'declared',clock_timestamp())
            """), {**ctx, "facility": facility_id, "type": cert_type, "issuer": body or None,
                    "file_name": item.get("fileName") or None})

    async def _certification_type(self, name: str, body: str) -> UUID:
        """The certification type with exactly this name, created when missing.

        Types are shared by code (a slug of the name). Two spellings with the same slug
        ("ISO 9001" / "iso 9001") must not share a row, or the manufacturer would get the
        other spelling back when the profile is reloaded; the second one gets its own code."""
        existing = await self.db.scalar(text(
            "SELECT id FROM certification_types WHERE name=:name ORDER BY (code=:code) DESC, id LIMIT 1"
        ), {"name": name, "code": slug(name)})
        if existing:
            return existing
        params = {"code": slug(name), "name": name, "issuer": body or None}
        created = await self.db.scalar(text("""
            INSERT INTO certification_types(code,name,issuer) VALUES (:code,:name,:issuer)
            ON CONFLICT (code) DO NOTHING RETURNING id
        """), params)
        if created:
            return created
        params["code"] = f'{slug(name)[:70]}_{hashlib.md5(name.encode()).hexdigest()[:8].upper()}'
        return await self.db.scalar(text("""
            INSERT INTO certification_types(code,name,issuer) VALUES (:code,:name,:issuer)
            ON CONFLICT (code) DO UPDATE SET name=certification_types.name RETURNING id
        """), params)

    async def _replace_infrastructure(self, ctx: dict, facility_id: UUID, values: dict) -> None:
        """Updates only the infrastructure answers that were sent (partial)."""
        for position, (code, category) in enumerate(INFRA_CATEGORIES.items()):
            if code not in values:
                continue
            item_id = await self.db.scalar(text("""
                INSERT INTO infrastructure_items(code,name,category,answer_type,display_order)
                VALUES (:code,:name,:category,'text',:position)
                ON CONFLICT (code) DO UPDATE SET name=infrastructure_items.name RETURNING id
            """), {"code": code, "name": INFRA_NAMES[code], "category": category, "position": position})
            # Update the existing answer row (older rows may have no facility_id),
            # otherwise insert one - never a second row for the same question.
            updated = await self.db.execute(text("""
                UPDATE manufacturer_infrastructure SET text_value=:value,facility_id=:facility,
                  updated_by_membership_id=:membership_id,version=version+1
                WHERE organization_id=:organization_id AND infrastructure_item_id=:item
                  AND (facility_id=:facility OR facility_id IS NULL)
                RETURNING id
            """), {**ctx, "facility": facility_id, "item": item_id,
                    "value": str(values.get(code) or "").strip() or None})
            if updated.first() is None:
                await self.db.execute(text("""
                    INSERT INTO manufacturer_infrastructure
                      (organization_id,facility_id,infrastructure_item_id,text_value,updated_by_membership_id)
                    VALUES (:organization_id,:facility,:item,:value,:membership_id)
                """), {**ctx, "facility": facility_id, "item": item_id,
                        "value": str(values.get(code) or "").strip() or None})

    async def _replace_faqs(self, ctx: dict, facility_id: UUID, faqs: list[dict]) -> None:
        # The wizard can remove FAQs, so the stored list mirrors it exactly.
        await self.db.execute(text("DELETE FROM manufacturer_faq_answers WHERE organization_id=:organization_id"), ctx)
        for position, faq in enumerate(faqs):
            question = str(faq.get("q") or "").strip()
            if not question:
                continue
            question_id = await self.db.scalar(text("""
                INSERT INTO manufacturer_faq_questions(question_code,question_text,answer_type,display_order)
                VALUES (:code,:question,'text',0)
                ON CONFLICT (question_code) DO UPDATE SET question_text=manufacturer_faq_questions.question_text
                RETURNING id
            """), {"code": f"CUSTOM_{slug(question)}", "question": question})
            await self.db.execute(text("""
                INSERT INTO manufacturer_faq_answers
                  (organization_id,facility_id,question_id,text_value,answered_by_membership_id,display_order)
                VALUES (:organization_id,:facility,:question,:answer,:membership_id,:position)
                ON CONFLICT (organization_id,facility_id,question_id)
                DO UPDATE SET text_value=EXCLUDED.text_value,display_order=EXCLUDED.display_order
            """), {**ctx, "facility": facility_id, "question": question_id,
                    "answer": str(faq.get("a") or ""), "position": position})

    # ------------------------------------------------------------------ step progress
    PROFILE_STEPS = 5          # Welcome, Company, Location, Certifications, Infrastructure & FAQ
    MACHINERY_STEPS = 7        # Details, Images, Raw materials, Labour, Logistics, Pricing, Review

    async def profile_step_errors(self, ctx: dict, step: int) -> list[str]:
        """Server-side check of a step the user marked as done (mirrors the wizard)."""
        row = (await self.db.execute(text("""
            SELECT o.display_name, op.about_company, f.address_line1, f.city, f.country_name
            FROM organizations o
            LEFT JOIN organization_profiles op ON op.organization_id=o.id
            LEFT JOIN facilities f ON f.organization_id=o.id AND f.is_headquarters AND f.status<>'suspended'
            WHERE o.id=:organization_id
        """), ctx)).first()
        blank = lambda v: not str(v or "").strip()
        errors = []
        if step == 2:
            if blank(row.display_name): errors.append("Company name is required.")
            if blank(row.about_company): errors.append("Tell buyers a little about your company.")
        if step == 3:
            if blank(row.address_line1): errors.append("Facility address is required.")
            if blank(row.city): errors.append("City is required.")
            if blank(row.country_name): errors.append("Please select a country.")
        return errors

    async def save_progress(self, ctx: dict, form_key: str, record_id: UUID, total: int,
                            progress: dict | None, client_key: UUID | None = None,
                            finished: bool = False) -> None:
        """Upsert the single progress row of a form instance (never duplicated)."""
        step = (progress or {}).get("step")
        completed = bool((progress or {}).get("completed"))
        next_step = (progress or {}).get("nextStep") or (min(step + 1, total) if step else None)
        await self.db.execute(text("""
            INSERT INTO manufacturer_form_progress
              (organization_id, form_key, record_id, client_key, current_step, completed_steps, total_steps,
               status, completed_at)
            VALUES (:organization_id, :form, :record, :client, COALESCE(:current, 1),
                    CASE WHEN :completed THEN ARRAY[CAST(:step AS smallint)] ELSE '{}'::smallint[] END,
                    :total, CASE WHEN :finished THEN 'completed' ELSE 'draft' END,
                    CASE WHEN :finished THEN now() END)
            ON CONFLICT (organization_id, form_key, record_id) DO UPDATE SET
              current_step = COALESCE(:current, manufacturer_form_progress.current_step),
              completed_steps = CASE
                WHEN :completed AND NOT (CAST(:step AS smallint) = ANY(manufacturer_form_progress.completed_steps))
                THEN array_append(manufacturer_form_progress.completed_steps, CAST(:step AS smallint))
                ELSE manufacturer_form_progress.completed_steps END,
              status = CASE WHEN :finished THEN 'completed' ELSE manufacturer_form_progress.status END,
              completed_at = CASE WHEN :finished THEN now() ELSE manufacturer_form_progress.completed_at END,
              updated_at = now()
        """), {**ctx, "form": form_key, "record": record_id, "client": client_key, "current": next_step,
                "completed": completed and step is not None, "step": step or 0, "total": total,
                "finished": finished})
        if form_key == "company_profile":
            # The profile form is complete once every step has been saved as done.
            await self.db.execute(text("""
                UPDATE manufacturer_form_progress SET
                  status = CASE WHEN completed_steps @> CAST(:all AS smallint[]) THEN 'completed' ELSE 'draft' END,
                  completed_at = CASE WHEN completed_steps @> CAST(:all AS smallint[])
                                      THEN COALESCE(completed_at, now()) END
                WHERE organization_id=:organization_id AND form_key='company_profile' AND record_id=:record
            """), {**ctx, "record": record_id, "all": list(range(1, total + 1))})

    async def form_progress(self, ctx: dict) -> list[dict]:
        rows = await self.db.execute(text("""
            SELECT form_key, record_id, current_step, completed_steps, total_steps, status, updated_at
            FROM manufacturer_form_progress WHERE organization_id=:organization_id
        """), ctx)
        return [dict(r._mapping) for r in rows]

    # ------------------------------------------------------------------ machinery drafts (step by step)
    async def find_file_by_key(self, ctx: dict, object_key: str) -> UUID | None:
        return await self.db.scalar(text("""
            SELECT id FROM files WHERE organization_id=:organization_id AND object_key=:key AND status='active'
        """), {**ctx, "key": object_key})

    async def create_machinery_draft(self, actor: Actor, client_key: UUID, changes: dict,
                                     images: list[tuple[UUID, bool]] | None, progress: dict | None) -> str:
        """First "Save & Next": create the draft machine + its progress row, once."""
        ctx = await self.context(actor)
        await self.db.execute(text("SELECT pg_advisory_xact_lock(hashtextextended(:k, 0))"),
                              {"k": f"xy-machinery-draft:{ctx['organization_id']}:{client_key}"})
        existing = await self.db.scalar(text("""
            SELECT record_id FROM manufacturer_form_progress
            WHERE organization_id=:organization_id AND client_key=:client
        """), {**ctx, "client": client_key})
        if existing:                       # repeated submission: same draft, nothing new
            await self.db.commit()
            return str(existing)
        if not str(changes.get("type") or "").strip() or not str(changes.get("industry") or "").strip():
            raise ValueError("Please select an industry and enter the machinery type.")
        machine_id = await self.db.scalar(text("""
            INSERT INTO machines (organization_id,facility_id,machinery_term_id,name,status,publication_status,created_at)
            VALUES (:organization_id,
                    (SELECT id FROM facilities WHERE organization_id=:organization_id AND is_headquarters
                       AND status<>'suspended' LIMIT 1),
                    :term, :name, 'active', 'draft', clock_timestamp())
            RETURNING id
        """), {**ctx, "term": await self._machinery_term(changes["type"]), "name": changes["type"].strip()})
        await self._apply_machinery_changes(machine_id, changes, images)
        await self.save_progress(ctx, "machinery", machine_id, self.MACHINERY_STEPS, progress, client_key)
        await self.db.commit()
        return str(machine_id)

    async def update_machinery_draft(self, actor: Actor, machine_id: str, changes: dict,
                                     images: list[tuple[UUID, bool]] | None, progress: dict | None,
                                     finish: str | None) -> None:
        ctx = await self.context(actor)
        machine = (await self.db.execute(text("""
            SELECT id FROM machines WHERE id=CAST(:id AS uuid) AND organization_id=:organization_id
        """), {**ctx, "id": machine_id})).first()
        if not machine:
            raise LookupError("Machinery listing not found")
        if "type" in changes and not str(changes["type"] or "").strip():
            raise ValueError("Machinery type is required.")
        if "industry" in changes and not str(changes["industry"] or "").strip():
            raise ValueError("Please select an industry.")
        await self._apply_machinery_changes(machine.id, changes, images)
        if finish:
            status, publication = MACHINE_STATUS[finish]
            await self.db.execute(text("""
                UPDATE machines SET status=:status, publication_status=:publication, version=version+1
                WHERE id=:id
            """), {"id": machine.id, "status": status, "publication": publication})
            progress = {"step": self.MACHINERY_STEPS, "completed": True, "nextStep": self.MACHINERY_STEPS}
        await self.save_progress(ctx, "machinery", machine.id, self.MACHINERY_STEPS, progress,
                                 finished=bool(finish))
        await self.db.commit()

    async def _machinery_term(self, machine_type: str) -> UUID:
        return await self.db.scalar(text("""
            INSERT INTO taxonomy_terms(term_type,term,code,status) VALUES ('machinery',:term,:code,'active')
            ON CONFLICT (term_type,code,taxonomy_version) DO UPDATE SET term=taxonomy_terms.term RETURNING id
        """), {"term": machine_type.strip(), "code": slug(machine_type)})

    async def _apply_machinery_changes(self, machine_id: UUID, changes: dict,
                                       images: list[tuple[UUID, bool]] | None) -> None:
        """Only the fields present in `changes` are written."""
        if str(changes.get("type") or "").strip():
            await self.db.execute(text("""
                UPDATE machines SET name=:name, machinery_term_id=:term, version=version+1 WHERE id=:id
            """), {"id": machine_id, "name": changes["type"].strip(), "term": await self._machinery_term(changes["type"])})
        if "technical" in changes:
            await self.db.execute(text("UPDATE machines SET description=:d WHERE id=:id"),
                                  {"id": machine_id, "d": changes["technical"] or None})
        for key, value in changes.items():
            if key in MACHINE_COLUMN_KEYS:
                continue
            await self.db.execute(text("""
                INSERT INTO machine_specs(machine_id,spec_code,value_text) VALUES (:machine,:code,:value)
                ON CONFLICT (machine_id,spec_code) DO UPDATE SET value_text=EXCLUDED.value_text
            """), {"machine": machine_id, "code": key,
                    "value": json.dumps(value) if isinstance(value, (dict, list)) else str(value or "")})
        if images is not None:                 # the image list was changed: replace it
            await self.db.execute(text("DELETE FROM machine_images WHERE machine_id=:id"), {"id": machine_id})
            for order, (file_id, primary) in enumerate(images):
                await self.db.execute(text("""
                    INSERT INTO machine_images(machine_id,file_id,display_order,alt_text)
                    VALUES (:machine,:file,:order,(SELECT name FROM machines WHERE id=:machine))
                """), {"machine": machine_id, "file": file_id, "order": 0 if primary else order + 1})

    # ------------------------------------------------------------------ machinery
    async def create_machinery(self, actor: Actor, data: dict, images: list[tuple[UUID, bool]]) -> str:
        ctx = await self.context(actor)
        term_id = await self.db.scalar(text("""
            INSERT INTO taxonomy_terms(term_type,term,code,status)
            VALUES ('machinery',:term,:code,'active')
            ON CONFLICT (term_type,code,taxonomy_version) DO UPDATE SET term=taxonomy_terms.term
            RETURNING id
        """), {"term": data["type"], "code": slug(data["type"])})
        status, publication = MACHINE_STATUS[data["status"]]
        facility_id = await self.db.scalar(text("""
            SELECT id FROM facilities WHERE organization_id=:organization_id AND is_headquarters=true
              AND status<>'suspended' LIMIT 1
        """), ctx)
        machine_id = await self.db.scalar(text("""
            INSERT INTO machines
              (organization_id,facility_id,machinery_term_id,name,description,status,publication_status,created_at)
            VALUES (:organization_id,:facility,:term,:name,:description,:status,:publication,clock_timestamp())
            RETURNING id
        """), {**ctx, "facility": facility_id, "term": term_id, "name": data["type"],
                "description": data.get("technical") or None, "status": status, "publication": publication})
        for key, value in data.items():
            if key in MACHINE_COLUMN_KEYS:
                continue
            await self.db.execute(text("""
                INSERT INTO machine_specs(machine_id,spec_code,value_text) VALUES (:machine,:code,:value)
            """), {"machine": machine_id, "code": key,
                    "value": json.dumps(value) if isinstance(value, (dict, list)) else str(value or "")})
        for order, (file_id, primary) in enumerate(images):
            await self.db.execute(text("""
                INSERT INTO machine_images(machine_id,file_id,display_order,alt_text)
                VALUES (:machine,:file,:order,:alt)
            """), {"machine": machine_id, "file": file_id, "order": 0 if primary else order + 1, "alt": data["type"]})
        await self.db.commit()
        return str(machine_id)

    async def set_machinery_status(self, actor: Actor, machine_id: str, display_status: str) -> None:
        ctx = await self.context(actor)
        status, publication = MACHINE_STATUS[display_status]
        result = await self.db.execute(text("""
            UPDATE machines SET status=:status,publication_status=:publication,version=version+1
            WHERE id=CAST(:id AS uuid) AND organization_id=:organization_id RETURNING id
        """), {**ctx, "id": machine_id, "status": status, "publication": publication})
        if not result.first():
            raise LookupError("Machinery listing not found")
        await self.db.commit()

    # ------------------------------------------------------------------ availability
    async def save_availability(self, actor: Actor, data: dict) -> None:
        ctx = await self.context(actor)
        await self.db.execute(text("""
            INSERT INTO manufacturer_availability_preferences
              (organization_id,calendar,recurring,capacity,updated_by_user_id)
            VALUES (:organization_id,CAST(:calendar AS jsonb),CAST(:recurring AS jsonb),
                    CAST(:capacity AS jsonb),:user_id)
            ON CONFLICT (organization_id) DO UPDATE SET calendar=EXCLUDED.calendar,
              recurring=EXCLUDED.recurring,capacity=EXCLUDED.capacity,updated_by_user_id=EXCLUDED.updated_by_user_id
        """), {**ctx, "calendar": json.dumps(data.get("calendar") or {}),
                "recurring": json.dumps(data.get("recurring")), "capacity": json.dumps(data.get("capacity"))})
        await self.db.commit()

    async def patch_availability(self, actor: Actor, changes: dict) -> None:
        """Only the parts sent (calendar / recurring / capacity) are written."""
        ctx = await self.context(actor)
        cols = [c for c in ("calendar", "recurring", "capacity") if c in changes]
        if not cols:
            return
        params = {c: json.dumps(changes[c] if c != "calendar" else (changes[c] or {})) for c in cols}
        await self.db.execute(text(
            f"INSERT INTO manufacturer_availability_preferences (organization_id, updated_by_user_id, {', '.join(cols)}) "
            f"VALUES (:organization_id, :user_id, {', '.join(f'CAST(:{c} AS jsonb)' for c in cols)}) "
            f"ON CONFLICT (organization_id) DO UPDATE SET updated_by_user_id=EXCLUDED.updated_by_user_id, "
            + ", ".join(f"{c}=EXCLUDED.{c}" for c in cols)), {**ctx, **params})
        await self.db.commit()

    # ------------------------------------------------------------------ bookings
    async def update_booking(self, actor: Actor, booking_id: str, decision: str) -> None:
        """Mirror of the dashboard buttons.

        accepted: New -> Booked ("Accept") and Reserved -> Booked ("Confirm booking")
        declined: New -> Cancelled ("Decline"), Reserved/Booked -> Cancelled ("Cancel")
        """
        ctx = await self.context(actor)
        current = await self.db.scalar(text("""
            SELECT status FROM manufacturer_booking_requests
            WHERE id=CAST(:id AS uuid) AND manufacturer_organization_id=:organization_id
        """), {**ctx, "id": booking_id})
        if current is None:
            raise LookupError("Booking request not found")
        if decision == "accepted":
            if current not in OPEN_STATUSES + RESERVED_STATUSES:
                raise ValueError("This booking request can no longer be accepted")
            sql = """UPDATE manufacturer_booking_requests SET status='confirmed',
                       manufacturer_response=COALESCE(manufacturer_response,'Accepted'),"""
        elif current in OPEN_STATUSES:
            sql = """UPDATE manufacturer_booking_requests SET status='declined',
                       decline_reason=COALESCE(decline_reason,'Declined by manufacturer'),"""
        elif current in RESERVED_STATUSES + BOOKED_STATUSES:
            sql = """UPDATE manufacturer_booking_requests SET status='cancelled',cancelled_at=now(),
                       cancellation_reason=COALESCE(cancellation_reason,'Cancelled by manufacturer'),"""
        else:
            raise ValueError("This booking request is already closed")
        await self.db.execute(text(sql + """
              responded_by_membership_id=:membership_id,responded_at=now(),version=version+1
            WHERE id=CAST(:id AS uuid) AND manufacturer_organization_id=:organization_id
        """), {**ctx, "id": booking_id})
        await self.db.commit()

    # ------------------------------------------------------------------ read model
    # Every list the Manufacturer dashboard needs, fetched in the SAME statement as the profile:
    # one database round trip instead of ten (each trip to the database costs network time).
    _SNAPSHOT_LISTS = (
        "certifications", "infrastructure", "faqs", "machines", "images", "availability", "bookings", "progress",
    )

    async def snapshot(self, actor: Actor | None, ctx: dict | None = None) -> dict:
        ctx = ctx or await self.context(actor)
        row = (await self.db.execute(text("""
            SELECT o.display_name,op.company_category,op.stated_production_capacity,op.production_capacity_label,
                   op.country_name account_country,op.contact_email,op.contact_phone,
                   op.about_company,op.vision,op.establishment_year,op.employee_count,
                   op.business_type,op.organization_size,
                   f.id facility_id,f.address_line1,f.city,f.state_province,f.country_name facility_country,
                   f.postal_code,f.sez_status,f.serviceable_areas,f.map_pin,
                   logo.object_key logo_object_key,cover.object_key cover_object_key,
                   mo.personal_information_completed,mo.company_information_completed,mo.location_completed,
                   mo.certification_completed,mo.infrastructure_completed,mo.faq_completed,mo.completion_percentage,
                   mo.status approval_status,
                   -- approval-first access of this user (app/manufacturer_access.py), same query
                   (SELECT row_to_json(x) FROM (__ACCESS_ROW__) x) AS access_row,
                   (SELECT ov.completeness FROM admin_manufacturer_overview ov
                     WHERE ov.organization_id=o.id) AS completeness,
                   (SELECT row_to_json(x) FROM (
                      SELECT s.id,s.kind,s.status,s.payload,s.review_feedback,s.updated_at,s.reviewed_at,
                             s.selected_company_id
                      FROM manufacturer_submissions s WHERE s.submitted_by_user_id=CAST(:user_id AS uuid)
                        AND s.kind <> 'update_request'
                      ORDER BY s.updated_at DESC, s.created_at DESC LIMIT 1) x) AS latest_submission,
                   (SELECT COALESCE(json_agg(x ORDER BY x.updated_at DESC), '[]'::json) FROM (
                      -- the user's own update requests for companies they do not manage: only
                      -- their own submitted values, status and feedback (no company data)
                      SELECT s.id, s.status, s.target_organization_id AS company_id,
                             t.display_name AS company_name, COALESCE(s.original_payload, s.payload) AS proposed,
                             s.review_feedback, s.created_at, s.updated_at, s.reviewed_at
                      FROM manufacturer_submissions s JOIN organizations t ON t.id = s.target_organization_id
                      WHERE s.submitted_by_user_id=CAST(:user_id AS uuid) AND s.kind = 'update_request'
                      ORDER BY s.updated_at DESC LIMIT 10) x) AS update_requests,
                   (SELECT COALESCE(json_agg(x ORDER BY x.created_at, x.id), '[]'::json) FROM (
                      SELECT ct.name,COALESCE(oc.issuer,ct.issuer) body,oc.status,oc.document_file_name,
                             oc.created_at,oc.id
                      FROM organization_certifications oc
                      JOIN certification_types ct ON ct.id=oc.certification_type_id
                      WHERE oc.organization_id=o.id) x) AS certifications,
                   (SELECT COALESCE(json_object_agg(ii.code, COALESCE(mi.text_value,'')), '{}'::json)
                      FROM manufacturer_infrastructure mi
                      JOIN infrastructure_items ii ON ii.id=mi.infrastructure_item_id
                      WHERE mi.organization_id=o.id) AS infrastructure,
                   (SELECT COALESCE(json_agg(x ORDER BY x.display_order, x.created_at), '[]'::json) FROM (
                      SELECT q.question_text q,a.text_value a,a.display_order,a.created_at
                      FROM manufacturer_faq_answers a JOIN manufacturer_faq_questions q ON q.id=a.question_id
                      WHERE a.organization_id=o.id) x) AS faqs,
                   (SELECT COALESCE(json_agg(x ORDER BY x.created_at DESC, x.id), '[]'::json) FROM (
                      SELECT m.id,m.name,m.description,m.status,m.publication_status,m.created_at,
                             COALESCE(jsonb_object_agg(ms.spec_code,ms.value_text)
                                      FILTER (WHERE ms.spec_code IS NOT NULL), '{}'::jsonb) specs
                      FROM machines m LEFT JOIN machine_specs ms ON ms.machine_id=m.id
                      WHERE m.organization_id=o.id GROUP BY m.id) x) AS machines,
                   (SELECT COALESCE(json_agg(x ORDER BY x.machine_id, x.display_order), '[]'::json) FROM (
                      SELECT mi.machine_id,f2.object_key,mi.display_order FROM machine_images mi
                      JOIN files f2 ON f2.id=mi.file_id JOIN machines m ON m.id=mi.machine_id
                      WHERE m.organization_id=o.id) x) AS images,
                   (SELECT row_to_json(x) FROM (
                      SELECT calendar,recurring,capacity FROM manufacturer_availability_preferences
                      WHERE organization_id=o.id LIMIT 1) x) AS availability,
                   (SELECT COALESCE(json_agg(x ORDER BY x.created_at DESC), '[]'::json) FROM (
                      SELECT br.id,COALESCE(bo.display_name,'Buyer') buyer,
                             COALESCE(cl.title,br.requirements,'Capacity request') item,
                             br.requested_start_date,br.status,br.created_at
                      FROM manufacturer_booking_requests br
                      JOIN organizations bo ON bo.id=br.demand_organization_id
                      LEFT JOIN manufacturer_capacity_listings cl ON cl.id=br.capacity_listing_id
                      WHERE br.manufacturer_organization_id=o.id) x) AS bookings,
                   (SELECT COALESCE(json_agg(x), '[]'::json) FROM (
                      SELECT form_key, record_id, current_step, completed_steps, total_steps, status, updated_at
                      FROM manufacturer_form_progress WHERE organization_id=o.id) x) AS progress
            FROM organizations o
            LEFT JOIN organization_profiles op ON op.organization_id=o.id
            LEFT JOIN facilities f ON f.organization_id=o.id AND f.is_headquarters=true AND f.status<>'suspended'
            LEFT JOIN files logo ON logo.id=op.logo_file_id
            LEFT JOIN files cover ON cover.id=op.cover_file_id
            LEFT JOIN manufacturer_onboarding mo ON mo.organization_id=o.id
            WHERE o.id=:organization_id
        """.replace("__ACCESS_ROW__", access.STATE_SQL.format(u="CAST(:user_id AS uuid)", o="o.id"))),
            ctx)).first()
        data = dict(row._mapping) if row else {}
        lists = {k: _json_value(data.pop(k, None)) for k in self._SNAPSHOT_LISTS}
        for booking in lists["bookings"] or []:
            if booking.get("requested_start_date"):
                booking["requested_start_date"] = date.fromisoformat(booking["requested_start_date"])
        for progress in lists["progress"] or []:
            if progress.get("updated_at"):
                progress["updated_at"] = datetime.fromisoformat(progress["updated_at"])
        return {
            "context": ctx,
            "profile": data,
            "certifications": lists["certifications"] or [],
            "infrastructure": lists["infrastructure"] or {},
            "faqs": lists["faqs"] or [],
            "machines": lists["machines"] or [],
            "images": lists["images"] or [],
            "availability": lists["availability"] or {},
            "bookings": lists["bookings"] or [],
            "progress": lists["progress"] or [],
        }
