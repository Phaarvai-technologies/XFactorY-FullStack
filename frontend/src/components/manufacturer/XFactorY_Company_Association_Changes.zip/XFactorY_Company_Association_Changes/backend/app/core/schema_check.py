"""Detects a database that is missing the migrations this backend needs.

A missing column otherwise only shows up as a failed request, so the check runs
at startup (logged) and at GET /health/ready.
"""
import logging

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncEngine

log = logging.getLogger("xy.schema")

MIGRATION_HINT = (
    "Run `python -m app.migrate` in the backend folder (with PYTHONPATH=.), or run "
    "database/migrations/004_*.sql, 005_*.sql and 006_*.sql in the Supabase SQL editor."
)

# (table, column or None for "table must exist", migration that adds it)
REQUIRED = [
    ("users", "personal_email", "024_personal_email.sql"),
    ("manufacturer_submissions", "correction_fields", "025_approval_first.sql"),
    ("manufacturer_onboarding", None, "XY_Database_Schema.sql"),
    ("manufacturer_availability_preferences", None, "004_manufacturer_api_support.sql"),
    ("facilities", "sez_status", "004_manufacturer_api_support.sql"),
    ("facilities", "serviceable_areas", "004_manufacturer_api_support.sql"),
    ("organization_profiles", "country_name", "006_frontend_field_support.sql"),
    ("organization_profiles", "production_capacity_label", "006_frontend_field_support.sql"),
    ("facilities", "country_name", "006_frontend_field_support.sql"),
    ("facilities", "map_pin", "006_frontend_field_support.sql"),
    ("organization_certifications", "document_file_name", "006_frontend_field_support.sql"),
    ("manufacturer_faq_answers", "display_order", "006_frontend_field_support.sql"),
    ("manufacturer_form_progress", None, "007_form_progress.sql"),
    ("organizations", "record_type", "008_admin_dashboard.sql"),
    ("admin_change_history", None, "008_admin_dashboard.sql"),
    ("admin_internal_notes", None, "008_admin_dashboard.sql"),
    ("user_activity_events", None, "008_admin_dashboard.sql"),
    ("admin_manufacturer_overview", "completeness", "008_admin_dashboard.sql"),
    ("admin_accounts", None, "009_admin_accounts.sql"),
    ("admin_sessions", None, "009_admin_accounts.sql"),
    ("email_deliveries", None, "010_email_deliveries.sql"),
    ("users", "welcome_email_sent_at", "011_welcome_email.sql"),
    ("visionary_profiles", None, "012_visionary_portal.sql"),
    ("visionary_projects", None, "012_visionary_portal.sql"),
    ("visionary_request_details", None, "012_visionary_portal.sql"),
    ("visionary_request_drafts", None, "012_visionary_portal.sql"),
    ("admin_accounts", "must_change_password", "013_admin_management.sql"),
    ("notifications", "popup_shown_at", "015_manufacturer_notifications.sql"),
    ("users", "record_type", "023_user_record_type.sql"),
    ("admin_internal_notes", "shared_with_manufacturer", "015_manufacturer_notifications.sql"),
    ("users", "registration_completed_at", "014_user_registration.sql"),
    ("registration_flows", None, "014_user_registration.sql"),
    ("users", "terms_accepted_at", "016_terms_acceptance.sql"),
    ("manufacturer_submissions", None, "017_manufacturer_approval.sql"),
    ("registration_settings", None, "018_registration_compat.sql"),
    ("manufacturer_submissions", "base_snapshot", "019_company_update_requests.sql"),
    ("manufacturer_submission_events", None, "019_company_update_requests.sql"),
    ("import_batches", None, "020_onboarding_source.sql"),
    ("organizations", "onboarding_source", "020_onboarding_source.sql"),
    ("manufacturer_submissions", "submitted_at", "020_onboarding_source.sql"),
    ("manufacturer_submission_events", "organization_id", "020_onboarding_source.sql"),
]


async def missing_schema(engine: AsyncEngine) -> list[str]:
    async with engine.connect() as conn:
        rows = await conn.execute(text("""
            SELECT table_name, column_name FROM information_schema.columns
            WHERE table_schema = 'public'
        """))
        columns = {(r.table_name, r.column_name) for r in rows}
    tables = {t for t, _ in columns}
    problems = []
    for table, column, migration in REQUIRED:
        if column is None and table not in tables:
            problems.append(f"table {table} (from {migration})")
        elif column is not None and (table, column) not in columns:
            problems.append(f"column {table}.{column} (from {migration})")
    return problems


async def log_schema_status(engine: AsyncEngine) -> list[str] | None:
    try:
        problems = await missing_schema(engine)
    except Exception as exc:  # noqa: BLE001 - startup must not crash on DB trouble
        log.error("Could not check the database schema: %s", exc)
        return None
    if problems:
        log.error("DATABASE IS MISSING MIGRATIONS - API calls will fail.\n  Missing: %s\n  Fix: %s",
                  "\n           ".join(problems), MIGRATION_HINT)
    else:
        log.info("Database schema OK")
    return problems
